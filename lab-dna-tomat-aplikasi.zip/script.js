/* Laboratorium Virtual Isolasi DNA Tomat — 20 slide */
(() => {
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const clamp = (v,a,b) => Math.max(a, Math.min(b, v));
let reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
const sleep = ms => new Promise(r => setTimeout(r, reduce ? 0 : ms));
const store = { get(k,d){ try{ const v = localStorage.getItem('dnatomat-'+k); return v===null?d:JSON.parse(v); }catch(e){ return d; } },
                set(k,v){ try{ localStorage.setItem('dnatomat-'+k, JSON.stringify(v)); }catch(e){} } };
const TOTAL = 20;

/* ---------------- suara ---------------- */
let soundOn = store.get('sound', true), actx = null;
function tone(f, d=.12, type='sine', when=0, vol=.14){
  if (!soundOn) return;
  try{ actx = actx || new (window.AudioContext||window.webkitAudioContext)();
    const t = actx.currentTime+when, o = actx.createOscillator(), g = actx.createGain();
    o.type = type; o.frequency.setValueAtTime(f,t); g.gain.setValueAtTime(vol,t); g.gain.exponentialRampToValueAtTime(.001,t+d);
    o.connect(g).connect(actx.destination); o.start(t); o.stop(t+d+.02); }catch(e){}
}
const sfx = { click(){ tone(660,.05,'square',0,.04); }, ok(){ tone(660,.1,'triangle'); tone(990,.15,'triangle',.1); }, bad(){ tone(200,.2,'sawtooth',0,.07); },
  pop(){ tone(880,.05,'sine',0,.07); }, pour(){ tone(260+Math.random()*90,.05,'sine',0,.035); }, chop(){ tone(150,.06,'square',0,.08); }, win(){ [523,659,784,1046].forEach((f,i)=>tone(f,.18,'triangle',i*.12)); } };
document.addEventListener('click', e => { if (e.target.closest('button')) sfx.click(); }, true);

/* ---------------- umum ---------------- */
let toastT = null;
function toast(msg, kind='ok'){ const t = $('#toast'); t.textContent = msg; t.className = 'toast '+kind; t.hidden = false; clearTimeout(toastT); toastT = setTimeout(()=>t.hidden = true, 3400);
  if (kind==='bad') sfx.bad(); else if (kind==='ok') sfx.ok(); }
function dialog(title, body, btns){ $('#dlgTitle').textContent = title; $('#dlgBody').innerHTML = body; const bb = $('#dlgBtns'); bb.innerHTML = '';
  btns.forEach(([l, fn, cls]) => { const b = document.createElement('button'); b.className = 'btn-y '+(cls||''); b.textContent = l; b.onclick = fn; bb.appendChild(b); }); $('#dlg').hidden = false; }
const closeDlg = () => $('#dlg').hidden = true;
$('#dlg').addEventListener('click', e => { if (e.target.id==='dlg') closeDlg(); });
document.addEventListener('keydown', e => { if (e.key==='Escape') closeDlg(); });
document.addEventListener('dragstart', e => e.preventDefault());

/* ---------------- ikon alat & bahan ---------------- */
const S_ = (w,h,inner) => `<svg viewBox="0 0 ${w} ${h}">${inner}</svg>`;
const IC = {
  mortar: S_(48,48,'<path d="M6,20 L42,20 C42,34 34,42 24,42 C14,42 6,34 6,20 Z" fill="#e9ecef" stroke="#1b2f6b" stroke-width="3"/><path d="M30,6 L22,26" stroke="#868e96" stroke-width="6" stroke-linecap="round"/>'),
  alu: S_(48,48,'<path d="M36,6 L18,34" stroke="#868e96" stroke-width="8" stroke-linecap="round"/><circle cx="17" cy="36" r="6" fill="#adb5bd" stroke="#1b2f6b" stroke-width="2"/>'),
  beker: S_(48,48,'<path d="M10,6 L10,40 C10,43 12,44 15,44 L33,44 C36,44 38,43 38,40 L38,6" fill="#f1f3f5" stroke="#1b2f6b" stroke-width="3"/><path d="M38,14 L32,14 M38,22 L32,22 M38,30 L32,30" stroke="#1b2f6b" stroke-width="2"/>'),
  ukur: S_(48,48,'<path d="M18,4 L30,4 L30,40 L34,44 L14,44 L18,40 Z" fill="#f1f3f5" stroke="#1b2f6b" stroke-width="3"/><path d="M30,12 L25,12 M30,20 L25,20 M30,28 L25,28 M30,36 L25,36" stroke="#1b2f6b" stroke-width="2"/>'),
  tabung: S_(48,48,'<path d="M18,4 L30,4 L30,38 C30,45 18,45 18,38 Z" fill="#f8f9fa" stroke="#1b2f6b" stroke-width="3"/>'),
  rak: S_(48,48,'<rect x="4" y="18" width="40" height="8" rx="2" fill="#c98b53" stroke="#6e4520" stroke-width="2.5"/><rect x="8" y="26" width="5" height="16" fill="#c98b53" stroke="#6e4520" stroke-width="2"/><rect x="35" y="26" width="5" height="16" fill="#c98b53" stroke="#6e4520" stroke-width="2"/><circle cx="16" cy="22" r="2.5" fill="#6e4520"/><circle cx="24" cy="22" r="2.5" fill="#6e4520"/><circle cx="32" cy="22" r="2.5" fill="#6e4520"/>'),
  corong: S_(48,48,'<path d="M6,8 L42,8 L28,26 L28,42 L20,42 L20,26 Z" fill="#f8f9fa" stroke="#1b2f6b" stroke-width="3" stroke-linejoin="round"/>'),
  saring: S_(48,48,'<circle cx="24" cy="24" r="18" fill="#fff" stroke="#1b2f6b" stroke-width="3"/><path d="M24,6 L24,42 M6,24 L42,24" stroke="#ced4da" stroke-width="2" stroke-dasharray="3 3"/>'),
  pipet: S_(48,48,'<path d="M24,14 L24,40 L22,46 L26,46 L24,40" fill="none" stroke="#1b2f6b" stroke-width="3"/><ellipse cx="24" cy="10" rx="7" ry="8" fill="#ff8787" stroke="#1b2f6b" stroke-width="3"/>'),
  pengaduk: S_(48,48,'<path d="M10,42 L38,6" stroke="#adb5bd" stroke-width="5" stroke-linecap="round"/><path d="M10,42 L38,6" stroke="#1b2f6b" stroke-width="1"/>'),
  pisau: S_(48,48,'<rect x="4" y="30" width="40" height="12" rx="3" fill="#c98b53" stroke="#6e4520" stroke-width="2.5"/><path d="M10,24 L34,10 L38,14 L14,28 Z" fill="#dee2e6" stroke="#1b2f6b" stroke-width="2.5"/><path d="M34,10 L42,6" stroke="#1b2f6b" stroke-width="5" stroke-linecap="round"/>'),
  sendok: S_(48,48,'<ellipse cx="14" cy="16" rx="8" ry="6" fill="#dee2e6" stroke="#1b2f6b" stroke-width="2.5"/><path d="M20,19 L42,32" stroke="#1b2f6b" stroke-width="4" stroke-linecap="round"/><ellipse cx="30" cy="38" rx="5" ry="4" fill="#dee2e6" stroke="#1b2f6b" stroke-width="2"/>'),
  penjepit: S_(48,48,'<path d="M6,40 L30,16 M10,44 L34,20" stroke="#c98b53" stroke-width="4" stroke-linecap="round"/><path d="M30,16 L40,8 M34,20 L42,14" stroke="#868e96" stroke-width="3"/>'),
  tomat: '<svg viewBox="0 0 120 120"><use href="#tomato"/></svg>',
  air: S_(48,48,'<path d="M10,6 L10,40 C10,43 12,44 15,44 L33,44 C36,44 38,43 38,40 L38,6" fill="#f1f3f5" stroke="#1b2f6b" stroke-width="3"/><path d="M12,18 L36,18 L36,40 C36,42 34,42 33,42 L15,42 C13,42 12,42 12,40 Z" fill="#74c0fc"/>'),
  garam: S_(48,48,'<path d="M14,16 L34,16 L32,44 L16,44 Z" fill="#fff" stroke="#1b2f6b" stroke-width="3"/><path d="M14,16 C14,8 34,8 34,16" fill="#adb5bd" stroke="#1b2f6b" stroke-width="3"/><text x="24" y="34" text-anchor="middle" font-size="8" font-weight="800" fill="#1b2f6b" font-family="Nunito">NaCl</text>'),
  deterjen: S_(48,48,'<rect x="14" y="14" width="20" height="30" rx="5" fill="#8ce99a" stroke="#1b2f6b" stroke-width="3"/><path d="M20,14 L20,8 L30,8 L30,5" fill="none" stroke="#1b2f6b" stroke-width="3"/><circle cx="38" cy="10" r="4" fill="#fff" stroke="#1b2f6b" stroke-width="2"/>'),
  etanol: S_(48,48,'<rect x="12" y="12" width="24" height="32" rx="5" fill="#d0ebff" stroke="#1b2f6b" stroke-width="3"/><rect x="18" y="4" width="12" height="8" fill="#1b2f6b"/><text x="24" y="32" text-anchor="middle" font-size="6.5" font-weight="800" fill="#1b2f6b" font-family="Nunito">ETANOL</text><text x="24" y="40" text-anchor="middle" font-size="6" font-weight="800" fill="#1b2f6b" font-family="Nunito">96%</text>'),
  es: S_(48,48,'<path d="M4,24 L44,24 L40,42 L8,42 Z" fill="#e7f5ff" stroke="#1b2f6b" stroke-width="3"/><rect x="10" y="16" width="9" height="9" rx="2" fill="#fff" stroke="#74c0fc" stroke-width="2"/><rect x="22" y="14" width="9" height="9" rx="2" fill="#fff" stroke="#74c0fc" stroke-width="2"/><rect x="32" y="18" width="8" height="8" rx="2" fill="#fff" stroke="#74c0fc" stroke-width="2"/>'),
  timer: S_(48,48,'<circle cx="24" cy="26" r="17" fill="#fff" stroke="#1b2f6b" stroke-width="3"/><path d="M24,14 L24,26 L32,30" stroke="#1b2f6b" stroke-width="3" fill="none" stroke-linecap="round"/><rect x="20" y="4" width="8" height="5" fill="#1b2f6b"/>'),
  campuran: S_(48,48,'<path d="M10,6 L10,40 C10,43 12,44 15,44 L33,44 C36,44 38,43 38,40 L38,6" fill="#f1f3f5" stroke="#1b2f6b" stroke-width="3"/><path d="M12,22 L36,22 L36,40 C36,42 34,42 33,42 L15,42 C13,42 12,42 12,40 Z" fill="#ff8a65"/>'),
  larutan: S_(48,48,'<path d="M10,6 L10,40 C10,43 12,44 15,44 L33,44 C36,44 38,43 38,40 L38,6" fill="#f1f3f5" stroke="#1b2f6b" stroke-width="3"/><path d="M12,16 L36,16 L36,40 C36,42 34,42 33,42 L15,42 C13,42 12,42 12,40 Z" fill="#c3fae8"/>'),
  spiritus: S_(48,48,'<path d="M14,26 L34,26 L36,44 L12,44 Z" fill="#dee2e6" stroke="#1b2f6b" stroke-width="3"/><rect x="21" y="20" width="6" height="6" fill="#868e96" stroke="#1b2f6b" stroke-width="2"/><path d="M24,4 C30,10 28,16 24,19 C20,16 18,10 24,4 Z" fill="#ff922b" stroke="#e8590c" stroke-width="2"/>'),
  kocok: S_(48,48,'<path d="M18,6 L30,6 L30,36 C30,44 18,44 18,36 Z" fill="#f8f9fa" stroke="#1b2f6b" stroke-width="3" transform="rotate(20 24 24)"/><path d="M6,14 L10,18 M4,26 L9,26 M40,10 L36,16 M44,24 L38,24" stroke="#e03131" stroke-width="3" stroke-linecap="round"/>'),
};

/* ---------------- state lab ---------------- */
function freshLab(){ return {
  sample:{picked:false, washN:0, cut:0},
  grind:{inMortar:false, v:0, done:false},
  sol:{beaker:false, water:0, waterDone:false, salt:null, det:null, stir:0, foam:false},
  ext:{vol:0, poured:false, stir:0, foam:false, waited:false, waiting:false},
  filt:{beaker2:false, funnel:false, paper:false, vol:0, done:false},
  ppt:{rack:false, tube:false, filtrate:0, filtDone:false, iced:false, clamp:false, eth:0, cold:null, mixed:false, shaken:false, poured:false},
  obs:{waited:false, waiting:false, zoomed:false, table:{}},
  wrong:[], k3bad:[] }; }
let L = store.get('lab', null) || freshLab();
let K3 = new Set(store.get('k3', []));
const saveLab = () => store.set('lab', L);

function calc(){
  const s = L.sol, e = L.ext, p = L.ppt;
  const det = s.det==='ok'?1 : s.det==='lebih'?.85 : s.det==='kurang'?.5 : .05;
  const salt = s.salt==='ok'?1 : s.salt==='lebih'?.8 : s.salt==='kurang'?.6 : .5;
  const tissue = Math.round(L.grind.v);
  const mem = e.poured ? Math.round(det * (e.waited?100: e.stir>=100?65:35)) : 0;
  const rel = Math.round(mem * tissue/100 * salt * (s.foam?.85:1) * (e.foam?.8:1) * (Math.abs(s.water-100)<=10?1:.85) * (e.vol>=40&&e.vol<=60?1:.85));
  const ratio = p.filtrate ? p.eth/p.filtrate : 0;
  const rf = ratio===0 ? 0 : ratio<.8 ? ratio/.8 : ratio>1.6 ? .9 : 1;
  const prec = L.obs.waited ? Math.round(rel * (L.filt.done?1:.8) * (p.filtrate>=4&&p.filtrate<=6?1:.85) * (p.cold?1:.65) * (p.mixed?.4:1) * (p.shaken?.3:1) * rf) : 0;
  const purity = clamp(25 + (L.filt.done?10:0) + (p.cold?5:0) + (s.salt==='ok'?10:0) + (p.mixed||p.shaken?-10:0), 5, 60);
  return { tissue, mem, rel, prec, purity, ratio };
}
function statusHTML(){
  const c = calc(), rows = [['Jaringan hancur',c.tissue,'#2fb344'],['Membran larut',c.mem,'#ff922b'],['DNA terlepas',c.rel,'#7c5cff'],['DNA mengendap',c.prec,'#2f7be6']];
  return `<div class="status"><div class="t"><b>Status isolasi</b><span>angka ilustrasi, dihitung dari tindakanmu</span></div>${rows.map(r=>`<div class="st">${r[0]}<span class="v">${r[1]}%</span><div class="bar2"><i style="width:${r[1]}%;background:${r[2]}"></i></div></div>`).join('')}</div>`;
}
function refreshStatus(){ const s = $('#stage .status'); if (s) s.outerHTML = statusHTML(); }

/* ---------------- gerakan ---------------- */
function circlePad(host, html, onAngle, onEnd){
  const g = document.createElement('div'); g.className = 'gest'; g.innerHTML = html; host.appendChild(g);
  const pad = g.querySelector('.pad'), dot = g.querySelector('.dot'); let prev = null, lastT = 0, closed = false;
  const pos = e => { const r = pad.getBoundingClientRect(); return {x:e.clientX-r.left-r.width/2, y:e.clientY-r.top-r.height/2, R:r.width/2}; };
  pad.addEventListener('pointerdown', e => { e.preventDefault(); pad.setPointerCapture?.(e.pointerId); prev = pos(e); lastT = performance.now(); });
  pad.addEventListener('pointermove', e => { if (!prev) return; const p = pos(e), now = performance.now(), dt = Math.max(1, now-lastT);
    let da = Math.atan2(p.y,p.x) - Math.atan2(prev.y,prev.x); if (da>Math.PI) da -= 2*Math.PI; if (da<-Math.PI) da += 2*Math.PI;
    const sp = Math.hypot(p.x-prev.x, p.y-prev.y)/dt; dot.style.left = (p.R+p.x-13)+'px'; dot.style.top = (p.R+p.y-13)+'px'; prev = p; lastT = now; onAngle(Math.abs(da), sp, dt); });
  ['pointerup','pointercancel'].forEach(ev => pad.addEventListener(ev, () => prev = null));
  return { el:g, close(){ if (closed) return; closed = true; g.remove(); onEnd && onEnd(); } };
}
function stirPanel(host, title, obj, key, foamKey, rate, done){
  let fast = 0, sm = 0;
  const pad = circlePad(host, `<h3>${title}</h3><p>Gerakkan jari melingkar di dalam lingkaran. <b>Perlahan</b> agar tidak berbusa.</p><div class="pad"><span class="dot" style="left:calc(50% - 13px);top:8px"></span></div>
    <div class="speed"><i style="left:0%"></i></div><p class="sp">Kecepatan: –</p><div class="prog"><i style="width:${obj[key]}%"></i></div><button class="mini" data-k>Aduk (tombol)</button>`,
    (da, sp, dt) => { sm = sm*.8 + sp*.2; pad.el.querySelector('.speed i').style.left = clamp(sm/2.2*100,0,100)+'%';
      pad.el.querySelector('.sp').textContent = 'Kecepatan: ' + (sm<1.2?'pelan ✓':sm<1.6?'sedang':'TERLALU CEPAT!');
      if (sm>=1.6){ fast += dt; if (fast>350 && !obj[foamKey]){ obj[foamKey] = true; toast('Terlalu cepat! Larutan berbusa dan DNA dapat patah.', 'bad'); } }
      obj[key] = Math.min(100, obj[key] + da*rate); pad.el.querySelector('.prog i').style.width = obj[key]+'%'; if (obj[key]>=100) pad.close(); },
    () => { saveLab(); done(); });
  pad.el.querySelector('[data-k]').onclick = () => { obj[key] = Math.min(100, obj[key]+25); pad.el.querySelector('.prog i').style.width = obj[key]+'%'; if (obj[key]>=100) pad.close(); };
}
function pourPanel(host, {title, note, unit, target, lo, hi, max, tilt=false, mixKey=null, mixObj=null, mixAt=55, rate=1, start=0, onDone}){
  const g = document.createElement('div'); g.className = 'gest'; let v = start, timer = null, fastMs = 0;
  g.innerHTML = `<h3>${title}</h3><p>${note}</p>${tilt?`<label for="tiltR" style="font-weight:800;font-size:.85rem">Kemiringan: <b id="tiltV">35°</b></label><input type="range" id="tiltR" min="10" max="80" value="35">`:''}
    <button class="holdbtn" id="holdB">Tahan untuk menuang</button><div class="vol"><i style="width:0%"></i><span class="tgt" style="left:${target/max*100}%"></span></div>
    <p class="vt">0 ${unit} (target ± ${target} ${unit})</p><button class="mini y" id="doneB">Selesai</button>`;
  host.appendChild(g);
  const tr = g.querySelector('#tiltR'); if (tr) tr.oninput = () => g.querySelector('#tiltV').textContent = tr.value+'°';
  const upd = () => { g.querySelector('.vol i').style.width = clamp(v/max*100,0,100)+'%'; g.querySelector('.vt').textContent = `${Math.round(v*10)/10} ${unit} (target ± ${target} ${unit})`; };
  const step = add => { v = Math.min(max, v + add); if (tilt && mixObj && +tr.value>mixAt){ fastMs += 60; if (fastMs>250 && !mixObj[mixKey]){ mixObj[mixKey] = true; toast('Terlalu miring! Cairan mengalir deras dan lapisan tercampur.', 'bad'); } } if (Math.random()<.35) sfx.pour(); upd(); };
  const go = e => { e.preventDefault(); if (timer) return; g.querySelector('#holdB').classList.add('held'); timer = setInterval(() => step(rate * (tilt ? +tr.value/35 : 1) * max/100), 60); };
  const stop = () => { clearInterval(timer); timer = null; g.querySelector('#holdB').classList.remove('held'); };
  const hb = g.querySelector('#holdB'); hb.addEventListener('pointerdown', go); ['pointerup','pointerleave','pointercancel'].forEach(ev => hb.addEventListener(ev, stop));
  hb.addEventListener('contextmenu', e => e.preventDefault());
  hb.addEventListener('keydown', e => { if (e.key===' '||e.key==='Enter'){ e.preventDefault(); step(max/10 * (tilt ? +tr.value/35 : 1)); } });
  g.querySelector('#doneB').onclick = () => { stop(); if (v<=0) return toast('Belum ada yang dituang.', 'warn'); g.remove();
    const ok = v>=lo && v<=hi; if (!ok) toast(`Volume ${Math.round(v*10)/10} ${unit} kurang tepat (anjuran ${lo}–${hi} ${unit}).`, 'warn'); onDone(v, ok); };
}

/* ---------------- mesin langkah praktikum ---------------- */
function labSlide(cfg){
  // cfg: {tray:[ids], names:{}, steps:[{t, items, done(), act(item, ctx)}], wrong:{id:msg}, draw(), zoom?(), sci}
  return { render(el){
      el.innerHTML = `<h2 class="ribbon">${cfg.ribbon}</h2>
        <div class="sim"><div>
          <div class="tray"><span class="tl">Alat &amp; bahan (ketuk untuk memakai)</span>${cfg.tray.map(id=>`<button class="tool" data-t="${id}">${IC[cfg.icon?.[id]||id]}<span>${cfg.names[id]}</span></button>`).join('')}</div>
          <div class="workbench" id="wb"></div></div>
          <div class="stack"><div class="task" id="task"></div><ol class="substeps" id="subs"></ol>${cfg.zoom?'<div class="zoomcard"><span class="kicker">Zoom molekul</span><svg viewBox="0 0 300 110" id="zsvg"></svg><p class="cap" id="zcap"></p></div>':''}<div class="sci">${cfg.sci}</div></div></div>
        ${statusHTML()}`;
      el.querySelectorAll('.tool').forEach(b => b.onclick = () => useTool(b.dataset.t));
      paint();
    }, locked: () => !cfg.steps.every(s => s.done()), lockMsg: 'Selesaikan semua langkah di slide ini dulu.' };
  function cur(){ return cfg.steps.find(s => !s.done()); }
  function paint(){
    const wb = $('#wb'); if (!wb) return;
    const gest = wb.querySelector('.gest'); wb.innerHTML = cfg.draw(); if (gest) wb.appendChild(gest);
    const c = cur();
    $('#task').className = 'task' + (c ? '' : ' ok'); $('#task').textContent = c ? '👉 ' + c.t : '✓ Langkah di slide ini selesai. Tekan Lanjut.';
    $('#subs').innerHTML = cfg.steps.map(s => `<li class="${s.done()?'ok':s===c?'now':''}">${s.t}</li>`).join('');
    $$('#stage .tool').forEach(b => { const s = cfg.steps.find(x => x.items.includes(b.dataset.t)); b.classList.toggle('done', !!s && s.done() && !(c && c.items.includes(b.dataset.t))); b.classList.toggle('pulse', !!(c && c.items.includes(b.dataset.t)) && guided()); });
    if (cfg.zoom){ const z = cfg.zoom(); $('#zsvg').innerHTML = z[0]; $('#zcap').textContent = z[1]; }
    refreshStatus(); updateNext();
  }
  function useTool(id){
    if ($('#wb .gest')) return toast('Selesaikan dulu kegiatan yang sedang berjalan.', 'warn');
    const c = cur();
    if (cfg.wrong && cfg.wrong[id] && !(c && c.items.includes(id))){ const w = cfg.wrong[id]; if (id==='kocok' && L.ppt.poured && !L.ppt.shaken){ L.ppt.shaken = true; } if (w.k3) L.k3bad.push(id); else L.wrong.push(id); saveLab(); return toast(w.msg || w, 'bad'); }
    if (!c){ return toast('Langkah di slide ini sudah selesai.', 'warn'); }
    // izinkan langkah yang urutannya bebas
    const target = cfg.steps.find(s => !s.done() && s.items.includes(id) && (s===c || s.free));
    if (!target){ const later = cfg.steps.find(s => s.items.includes(id));
      if (later && later.done()) return toast('Sudah dilakukan.', 'warn');
      L.wrong.push(id); saveLab(); return toast(later ? `Belum saatnya. Lakukan dulu: ${c.t}` : 'Alat/bahan ini tidak dipakai pada langkah ini.', 'bad'); }
    target.act(id, { paint, wb: $('#wb') });
    saveLab(); paint();
  }
}
const guided = () => store.get('guided', true);

/* ---------------- gambar meja ---------------- */
const tomatoBig = (x,y,s=1,wet=false) => `<g transform="translate(${x},${y}) scale(${s})"><path d="M0,-30 C26,-31 40,-12 39,8 C37,28 20,38 0,38 C-20,38 -37,28 -39,8 C-40,-12 -26,-31 0,-30 Z" fill="#e8432e" stroke="#a3241a" stroke-width="4"/><path d="M0,-29 L-10,-38 L-2,-34 L0,-44 L3,-34 L12,-38 L4,-29 Z" fill="#2f9e44" stroke="#1e6b2d" stroke-width="2"/><path d="M-20,-14 C-25,-6 -26,2 -25,10" stroke="#ff8a7a" stroke-width="5" fill="none" stroke-linecap="round"/>${wet?'<circle cx="18" cy="-10" r="3" fill="#a5d8ff"/><circle cx="-8" cy="20" r="2.5" fill="#a5d8ff"/><circle cx="24" cy="14" r="2" fill="#a5d8ff"/>':''}</g>`;
function drawS12(){
  const s = L.sample, washed = s.washN>=3;
  let h = `<svg viewBox="0 0 320 220"><rect x="14" y="150" width="120" height="40" rx="8" fill="#dee2e6" stroke="#1b2f6b" stroke-width="3"/><path d="M20,150 L128,150 L120,186 L28,186 Z" fill="#a5d8ff" opacity=".6"/>
    <text x="74" y="208" text-anchor="middle" font-family="Nunito" font-weight="800" font-size="11" fill="#1b2f6b">bak cuci</text>
    <rect x="160" y="160" width="150" height="26" rx="6" fill="#c98b53" stroke="#6e4520" stroke-width="3"/><text x="235" y="208" text-anchor="middle" font-family="Nunito" font-weight="800" font-size="11" fill="#1b2f6b">talenan</text>`;
  if (s.picked && !washed) h += tomatoBig(74, 130, 1, s.washN>0) + (s.washN>0?`<path d="M60,40 C62,70 66,90 70,100" stroke="#74c0fc" stroke-width="6" stroke-linecap="round" fill="none" opacity=".8"/>`:'');
  if (washed && s.cut===0) h += tomatoBig(235, 128, 1, true);
  if (s.cut>0){ const n = s.cut*2; for (let i=0;i<n;i++){ const x = 176+(i%6)*22, y = 138+((i/6)|0)*14; h += `<path d="M${x},${y} a9,9 0 0 1 18,0 Z" fill="#e8432e" stroke="#a3241a" stroke-width="2"/><circle cx="${x+9}" cy="${y-3}" r="1.5" fill="#ffe066"/>`; }
    h += `<g transform="translate(${250-s.cut*6},${80+(s.cut%2)*10}) rotate(-30)"><path d="M0,0 L50,-6 L52,4 L2,10 Z" fill="#dee2e6" stroke="#1b2f6b" stroke-width="2.5"/><rect x="50" y="-7" width="26" height="12" rx="4" fill="#1b2f6b"/></g>`; }
  if (s.cut>=6) h += `<text x="235" y="120" text-anchor="middle" font-family="Nunito" font-weight="800" font-size="12" fill="#1b2f6b">± 50 g potongan tomat</text>`;
  return h + '</svg>';
}
function mortarSVG(fill, chunks, color='#ff7a5c', extra=''){
  let h = `<svg viewBox="0 0 320 220"><ellipse cx="160" cy="192" rx="100" ry="10" fill="#495057" opacity=".2"/><path d="M70,90 L250,90 C250,150 210,190 160,190 C110,190 70,150 70,90 Z" fill="#e9ecef" stroke="#1b2f6b" stroke-width="5"/>
    <ellipse cx="160" cy="90" rx="90" ry="14" fill="#f8f9fa" stroke="#1b2f6b" stroke-width="4"/>`;
  if (fill>0) h += `<ellipse cx="160" cy="${150-fill*0.5}" rx="${60+fill*0.25}" ry="12" fill="${color}" stroke="#a3241a" stroke-width="2"/><path d="M${100-fill*.2},${150-fill*.5} C110,180 210,180 ${220+fill*.2},${150-fill*.5}" fill="${color}"/>`;
  for (let i=0;i<chunks;i++){ const x = 120+(i%5)*18, y = 128-((i/5)|0)*12; h += `<path d="M${x},${y} a9,9 0 0 1 18,0 Z" fill="#e8432e" stroke="#a3241a" stroke-width="2"/>`; }
  return h + extra + '</svg>';
}
function drawS13(){ const g = L.grind; if (!g.inMortar) return mortarSVG(0,0) ; const k = g.v/100;
  return mortarSVG(10+k*50, Math.round(12*(1-k)), '#ff7a5c', `<path d="M238,20 L186,${120-k*10}" stroke="#868e96" stroke-width="16" stroke-linecap="round"/><circle cx="184" cy="${122-k*10}" r="12" fill="#adb5bd" stroke="#1b2f6b" stroke-width="3"/>`); }
function beakerSVG(x, y, level, color, opts={}){
  let h = `<g transform="translate(${x},${y})"><path d="M0,0 L0,120 C0,128 6,132 14,132 L86,132 C94,132 100,128 100,120 L100,0" fill="#f8f9fa" fill-opacity=".6" stroke="#1b2f6b" stroke-width="4"/>
    ${[0,1,2,3].map(i=>`<line x1="100" y1="${20+i*26}" x2="90" y2="${20+i*26}" stroke="#1b2f6b" stroke-width="2"/>`).join('')}`;
  if (level>0) h += `<path d="M3,${130-level} L97,${130-level} L97,120 C97,126 92,129 86,129 L14,129 C8,129 3,126 3,120 Z" fill="${color}"/>`;
  if (opts.salt) h += [0,1,2].map(i=>`<rect x="${26+i*20}" y="${126-level/2+(i%2)*8}" width="5" height="5" fill="#fff" stroke="#868e96" transform="rotate(45 ${28+i*20} ${128-level/2+(i%2)*8})"/>`).join('');
  if (opts.foam) h += Array.from({length:12},(_,i)=>`<circle cx="${10+(i*17)%80}" cy="${126-level-(i%3)*8}" r="7" fill="#fff" stroke="#adb5bd" stroke-width="2"/>`).join('');
  else if (opts.bubbles) h += Array.from({length:4},(_,i)=>`<circle cx="${18+i*20}" cy="${127-level}" r="4" fill="#fff" stroke="#adb5bd" stroke-width="1.5"/>`).join('');
  if (opts.label) h += `<text x="50" y="152" text-anchor="middle" font-family="Nunito" font-weight="800" font-size="11" fill="#1b2f6b">${opts.label}</text>`;
  return h + '</g>';
}
function drawS14(){
  const s = L.sol; let h = `<svg viewBox="0 0 320 220">`;
  if (s.beaker){ const lvl = s.water*0.75 + (s.det?6:0); h += beakerSVG(150, 50, lvl, s.det ? '#c3fae8' : '#d0ebff', {salt:!!s.salt, foam:s.foam, bubbles:!!s.det, label:'gelas beker'}); }
  if (!s.waterDone && s.beaker) h += `<g transform="translate(40,40)"><path d="M18,0 L50,0 L50,130 L60,140 L8,140 L18,130 Z" fill="#f8f9fa" fill-opacity=".6" stroke="#1b2f6b" stroke-width="3"/>${s.water>0?`<rect x="21" y="${130-s.water*1.1}" width="26" height="${s.water*1.1}" fill="#74c0fc"/>`:''}${[0,1,2,3,4].map(i=>`<line x1="50" y1="${20+i*22}" x2="42" y2="${20+i*22}" stroke="#1b2f6b" stroke-width="2"/>`).join('')}<text x="34" y="158" text-anchor="middle" font-family="Nunito" font-weight="800" font-size="11" fill="#1b2f6b">gelas ukur</text></g>`;
  if (s.stir>0 && s.stir<100) h += `<path d="M240,20 L200,150" stroke="#adb5bd" stroke-width="6" stroke-linecap="round"/>`;
  return h + '</svg>';
}
function drawS15(){ const e = L.ext; const fill = 50 + Math.min(e.vol,60)*0.6;
  return mortarSVG(e.poured ? fill : 60, 0, e.poured ? '#ff9e80' : '#ff7a5c', (e.waiting||e.waited)?`<g transform="translate(276,46)"><circle r="24" fill="#fff" stroke="#1b2f6b" stroke-width="4"/><path d="M0,-14 L0,0 L9,7" stroke="#1b2f6b" stroke-width="4" fill="none" stroke-linecap="round"/></g>`:'' + (e.foam?Array.from({length:8},(_,i)=>`<circle cx="${110+i*14}" cy="${100}" r="6" fill="#fff" stroke="#adb5bd"/>`).join(''):'')); }
function drawS16(){
  const f = L.filt; let h = `<svg viewBox="0 0 320 220">`;
  if (f.beaker2) h += beakerSVG(170, 80, f.vol*0.9, '#ffd8a8', {label:'filtrat'});
  if (f.funnel) h += `<path d="M150,40 L290,40 L232,96 L232,120 L208,120 L208,96 Z" fill="#f8f9fa" fill-opacity=".7" stroke="#1b2f6b" stroke-width="4" stroke-linejoin="round"/>`;
  if (f.paper) h += `<path d="M158,44 L282,44 L220,100 Z" fill="#fff" stroke="#adb5bd" stroke-width="3"/>`;
  if (f.done || f.vol>0) h += `<ellipse cx="220" cy="54" rx="44" ry="8" fill="#d9480f" opacity=".75"/><text x="300" y="56" text-anchor="end" font-family="Nunito" font-weight="800" font-size="11" fill="#1b2f6b">ampas</text>`;
  if (f.vol>0 && !f.done) h += `<circle cx="220" cy="128" r="4" fill="#ffd8a8" stroke="#e8590c"/>`;
  if (!f.done) h += beakerSVG(20, 80, 70, '#ff9e80', {label:'campuran'});
  return h + '</svg>';
}
function drawS17(){
  const p = L.ppt; let h = `<svg viewBox="0 0 320 220">`;
  h += `<g transform="translate(14,120)"><path d="M0,20 L90,20 L82,80 L8,80 Z" fill="#e7f5ff" stroke="#1b2f6b" stroke-width="3"/>${[10,30,52,68].map((x,i)=>`<rect x="${x}" y="${10+i%2*6}" width="14" height="14" rx="3" fill="#fff" stroke="#74c0fc" stroke-width="2"/>`).join('')}
    <g transform="translate(${p.iced?30:110},${p.iced?-30:-40})"><rect width="30" height="48" rx="6" fill="#d0ebff" stroke="#1b2f6b" stroke-width="3"/><rect x="8" y="-10" width="14" height="10" fill="#1b2f6b"/><text x="15" y="30" text-anchor="middle" font-family="Nunito" font-weight="800" font-size="7" fill="#1b2f6b">ETANOL</text></g>
    <text x="45" y="98" text-anchor="middle" font-family="Nunito" font-weight="800" font-size="11" fill="#1b2f6b">wadah es</text></g>`;
  if (p.rack) h += `<rect x="170" y="170" width="130" height="12" rx="3" fill="#c98b53" stroke="#6e4520" stroke-width="3"/><rect x="180" y="182" width="8" height="24" fill="#c98b53" stroke="#6e4520" stroke-width="2"/><rect x="282" y="182" width="8" height="24" fill="#c98b53" stroke="#6e4520" stroke-width="2"/>`;
  if (p.tube){
    const fh = p.filtrate*12, eh = Math.min(p.eth,10)*12, bottom = 200, fy = bottom-fh, ey = fy-eh;
    h += `<g transform="rotate(${p.clamp && !p.poured ? -25 : 0} 235 200)"><path d="M222,40 L222,192 C222,210 248,210 248,192 L248,40" fill="#f8f9fa" fill-opacity=".6" stroke="#1b2f6b" stroke-width="4"/>
      ${fh?`<path d="M225,${fy} L245,${fy} L245,192 C245,205 225,205 225,192 Z" fill="${p.mixed||p.shaken?'#ffe8d6':'#ffd8a8'}"/>`:''}
      ${eh?`<rect x="225" y="${ey}" width="20" height="${eh}" fill="${p.mixed||p.shaken?'#ffe8d6':'#d0ebff'}"/>`:''}
      ${p.clamp?`<path d="M200,70 L222,80 M200,86 L222,92" stroke="#c98b53" stroke-width="5" stroke-linecap="round"/>`:''}</g>`;
    if (fh) h += `<text x="256" y="${Math.min(196,fy+18)}" font-family="Nunito" font-weight="800" font-size="11" fill="#1b2f6b">filtrat ${p.filtrate} mL</text>`;
    if (eh && !p.mixed && !p.shaken) h += `<text x="256" y="${ey+12}" font-family="Nunito" font-weight="800" font-size="11" fill="#1b2f6b">etanol</text>`;
  }
  if (p.tube && !p.filtDone && p.filtrate>0) h += `<g transform="translate(228,${20})"><path d="M7,10 L7,30" stroke="#1b2f6b" stroke-width="3"/><ellipse cx="7" cy="6" rx="6" ry="7" fill="#ff8787" stroke="#1b2f6b" stroke-width="2.5"/></g>`;
  return h + '</svg>';
}
function zoomCells(){ const br = Math.round(L.grind.v/100*6);
  return [Array.from({length:6},(_,i)=>{ const x = 8+i*48, b = i<br; return `<rect x="${x}" y="22" width="42" height="64" rx="6" fill="#fff4e6" stroke="#2f7d1f" stroke-width="6" ${b?'stroke-dasharray="14 10"':''}/><circle cx="${x+21}" cy="54" r="9" fill="#d0bfff" stroke="#5f3dc4" stroke-width="2"/><ellipse cx="${x+12}" cy="34" rx="5" ry="3" fill="#ff922b"/>`; }).join(''),
    `${br} dari 6 dinding sel robek. Bulatan jingga = kromoplas (plastida pemberi warna merah).`]; }
function zoomMembrane(){
  const e = L.ext, s = L.sol;
  const lip = (x,y,f) => `<g transform="translate(${x},${y}) ${f?'rotate(180)':''}"><circle r="4.5" fill="#ff922b" stroke="#1b2f6b"/><path d="M-1.5,4 L-1.5,13 M1.5,4 L1.5,13" stroke="#1b2f6b" stroke-width="1.5"/></g>`;
  const mic = (x,y) => `<g transform="translate(${x},${y})">${[0,1,2,3,4,5,6,7].map(k=>`<g transform="rotate(${k*45})"><circle cx="0" cy="-13" r="3.5" fill="${k%2?'#20c997':'#ff922b'}" stroke="#1b2f6b"/><path d="M0,-9 L0,-2" stroke="#1b2f6b" stroke-width="1.5"/></g>`).join('')}</g>`;
  if (!e.poured) return [Array.from({length:14},(_,i)=>lip(20+i*19,24,false)+lip(20+i*19,50,true)).join('') + `<path d="M30,92 C60,74 90,110 120,92 C150,74 180,110 210,92" stroke="#2f7be6" stroke-width="5" fill="none" opacity=".3"/>`, 'Membran sel dan membran inti (lapisan ganda lipid, jingga) masih utuh. DNA terkurung di dalam inti.'];
  if (!e.waited) return [Array.from({length:14},(_,i)=> i%3===1?'':lip(20+i*19,24,false)+lip(20+i*19,50,true)).join('') + [70,170,240].map(x=>mic(x,37)).join(''), 'Detergen (hijau) mulai membongkar membran menjadi misel. Diamkan agar prosesnya tuntas.'];
  return [[40,120,200,270].map(x=>mic(x,28)).join('') + `<path d="M20,82 C50,62 80,102 110,82 C140,62 170,102 200,82 C230,62 255,100 285,82" fill="none" stroke="#2f7be6" stroke-width="5"/>` +
    (s.salt ? [45,95,140,188,232,272].map((x,i)=>`<g transform="translate(${x},${i%2?66:100})"><circle r="7" fill="#8ce99a" stroke="#1b2f6b"/><text y="3.5" text-anchor="middle" font-size="8" font-weight="800" fill="#1b2f6b" font-family="Nunito">Na⁺</text></g>`).join('') : ''),
    s.salt ? 'Membran larut menjadi misel. DNA keluar ke larutan, dan ion Na⁺ mengurangi tolakan antar-gugus fosfat yang bermuatan negatif.' : 'DNA keluar, tetapi tanpa garam muatan negatifnya saling tolak sehingga sulit beragregasi.'];
}
function zoomPpt(){ const p = L.ppt;
  if (!p.eth) return [`<rect width="300" height="110" fill="#ffd8a8"/>${[20,110,200].map((x,i)=>`<path d="M${x},${30+i*20} c12,-14 24,14 36,0 c12,-14 24,14 36,0" stroke="#2f7be6" stroke-width="4" fill="none"/>`).join('')}${Array.from({length:14},(_,i)=>`<circle cx="${12+i*21}" cy="${12+(i*37)%90}" r="3.5" fill="#74c0fc"/>`).join('')}`, 'DNA larut dalam filtrat, dikelilingi molekul air (titik biru).'];
  const m = p.mixed||p.shaken;
  return [`<rect width="300" height="55" fill="${m?'#ffe8d6':'#d0ebff'}"/><rect y="55" width="300" height="55" fill="${m?'#ffe8d6':'#ffd8a8'}"/><g transform="translate(150,55)">${Array.from({length:m?2:6},(_,i)=>`<path d="M${-60+i*4},${-6+i*2} c14,-12 28,12 42,0 c14,-12 28,12 42,0" stroke="#2f7be6" stroke-width="3" fill="none"/>`).join('')}</g>`,
    m ? 'Lapisan tercampur: batas lapisan tidak terbentuk, jadi hanya sedikit DNA yang beragregasi.' : 'Di batas lapisan, DNA yang sukar larut dalam etanol beragregasi dan mulai mengendap.'];
}

/* ---------------- konten slide ---------------- */
const SL = [];
const helixAnim = `<svg viewBox="0 0 320 240" class="illus" id="dnaSvg">${Array.from({length:10},(_,i)=>{ const y = 20+i*21, a = i*.75, x1 = 160+Math.sin(a)*80, x2 = 160-Math.sin(a)*80, pr = [['A','T'],['G','C'],['T','A'],['C','G']][i%4];
  return `<line x1="${x1}" y1="${y}" x2="${x2}" y2="${y}" stroke="#adb5bd" stroke-width="5"/><g class="hot" data-h="basa"><circle cx="${(x1*2+x2)/3}" cy="${y}" r="7" fill="${['#ff6b6b','#fcc419','#51cf66','#339af0'][i%4]}"/><circle cx="${(x1+x2*2)/3}" cy="${y}" r="7" fill="${['#51cf66','#339af0','#ff6b6b','#fcc419'][i%4]}"/></g>
  <line class="hot" data-h="hidrogen" x1="${(x1*2+x2)/3+8}" y1="${y}" x2="${(x1+x2*2)/3-8}" y2="${y}" stroke="#1b2f6b" stroke-width="2" stroke-dasharray="3 3"/>
  <g class="hot" data-h="fosfat"><circle cx="${x1}" cy="${y}" r="10" fill="#2f7be6" stroke="#1b2f6b" stroke-width="2"/><text x="${x1}" y="${y+4}" text-anchor="middle" font-size="11" font-weight="800" fill="#fff" font-family="Nunito">−</text></g>
  <g class="hot" data-h="gula"><rect x="${x2-9}" y="${y-9}" width="18" height="18" rx="4" fill="#7c5cff" stroke="#1b2f6b" stroke-width="2"/></g>`; }).join('')}</svg>`;
const HX = { fosfat:['Gugus fosfat','Bagian tulang punggung DNA yang bermuatan negatif (−). Muatan ini membuat DNA larut dalam air dan menjadi alasan garam dipakai saat isolasi.'],
  gula:['Gula deoksiribosa','Gula berkarbon lima yang bersama fosfat membentuk tulang punggung DNA.'],
  basa:['Basa nitrogen','Adenin (A), timin (T), guanin (G), dan sitosin (C). Urutan basa inilah yang menyimpan informasi genetik.'],
  hidrogen:['Ikatan hidrogen','Menghubungkan pasangan basa A–T (2 ikatan) dan G–C (3 ikatan) sehingga kedua untai membentuk heliks ganda.'] };
const CELL = { dinding:['Dinding sel','Lapisan kaku dari selulosa (dan pektin pada tomat). Harus dirusak secara mekanik.', false],
  membran:['Membran sel','Lapisan ganda lipid yang membungkus sitoplasma. Dilarutkan oleh detergen.', false],
  inti:['Inti sel (nukleus)','Lokasi utama DNA, tersimpan sebagai kromatin bersama protein histon. Dibungkus membran inti.', true],
  mito:['Mitokondria','Memiliki DNA sendiri (DNA mitokondria) dalam jumlah kecil.', 'sec'],
  plastida:['Plastida (kloroplas/kromoplas)','Pada buah tomat matang, kloroplas berubah menjadi kromoplas berpigmen likopen. Plastida juga memiliki DNA sendiri.', 'sec'],
  vakuola:['Vakuola','Kantong berisi cairan sel. Tidak menyimpan DNA.', false] };
const TOOLS = [['mortar','Mortar dan alu','1 set','Menghaluskan tomat'],['beker','Gelas beker','2 buah','Wadah larutan dan filtrat'],['ukur','Gelas ukur','1 buah','Mengukur volume larutan'],['tabung','Tabung reaksi','1–2 buah','Wadah pengamatan DNA'],['rak','Rak tabung reaksi','1 buah','Menempatkan tabung'],['corong','Corong','1 buah','Membantu penyaringan'],['saring','Kertas saring/kain kasa','Secukupnya','Menyaring ampas'],['pipet','Pipet tetes','1 buah','Memindahkan cairan'],['pengaduk','Batang pengaduk','1 buah','Mengaduk larutan'],['pisau','Pisau dan talenan','1 set','Memotong tomat'],['sendok','Sendok ukur','1 buah','Menakar bahan'],['penjepit','Penjepit tabung','1 buah','Membantu memegang tabung']];
const MATS = [['tomat','Tomat matang','± 50 gram','Sumber DNA'],['air','Air/akuades','100 mL','Pelarut larutan ekstraksi'],['garam','Garam dapur (NaCl)','½ sendok teh','Ion Na⁺ mengurangi tolakan muatan negatif antarmolekul DNA sehingga DNA dapat beragregasi'],['deterjen','Detergen cair','1 sendok makan','Melarutkan membran sel dan membran inti (lipid) sehingga DNA keluar'],['etanol','Etanol 90–96% dingin','± 5 mL per 5 mL filtrat','DNA sukar larut dalam etanol sehingga mengendap (presipitasi)'],['es','Es batu','Secukupnya','Mendinginkan etanol agar pengendapan lebih banyak']];
const K3L = ['Saya memakai jas laboratorium dan sarung tangan.','Saya berhati-hati saat memakai pisau dan peralatan kaca.','Saya tidak akan mencicipi bahan praktikum.','Saya menjauhkan alkohol dari api dan sumber panas.','Saya memakai alkohol secukupnya di tempat berventilasi baik.','Saya bekerja di bawah pengawasan guru.'];

// 1
SL.push({ title:'Halaman Pembuka', nonav:true, render(el){ el.innerHTML = `<div class="cover"><div class="cover-art"><svg class="student bob" viewBox="0 0 120 220"><use href="#student"/></svg></div>
  <div class="cover-text"><div class="cover-icons"><svg class="tomato float" viewBox="0 0 120 120"><use href="#tomato"/></svg><svg class="helix spin" viewBox="0 0 60 120"><use href="#helix"/></svg><svg class="tube-ic" viewBox="0 0 40 100"><use href="#tubeic"/></svg></div>
  <h1 class="logo"><span class="small-l">Mengungkap Materi Genetik</span><span>Isolasi DNA</span><span>Buah Tomat</span></h1>
  <p class="tag">Praktikum virtual · <i>Solanum lycopersicum</i></p><p class="sub">Biologi SMA · Genetika &amp; Bioteknologi</p>
  <button class="btn-y big" id="startB">Mulai belajar ▶</button></div></div>`; $('#startB').onclick = () => show(2); } });
// 2
SL.push({ title:'Apersepsi', render(el){ const a = store.get('ap', {});
  el.innerHTML = `<h2 class="ribbon">Apersepsi</h2><div class="split"><svg viewBox="0 0 320 200" class="illus">
    <use href="#tomato" x="10" y="50" width="90" height="90"/><path d="M104,96 L130,96" stroke="#1b2f6b" stroke-width="4" marker-end="url(#)"/><path d="M124,88 L134,96 L124,104" fill="none" stroke="#1b2f6b" stroke-width="4"/>
    <rect x="140" y="56" width="80" height="80" rx="12" fill="#fff4e6" stroke="#2f7d1f" stroke-width="7"/><circle cx="180" cy="96" r="16" fill="#d0bfff" stroke="#5f3dc4" stroke-width="3"/>
    <path d="M224,96 L250,96" stroke="#1b2f6b" stroke-width="4"/><path d="M244,88 L254,96 L244,104" fill="none" stroke="#1b2f6b" stroke-width="4"/><use href="#helix" x="262" y="46" width="44" height="100"/>
    <g font-family="Nunito" font-weight="800" font-size="12" fill="#1b2f6b" text-anchor="middle"><text x="55" y="160">buah tomat</text><text x="180" y="160">sel</text><text x="284" y="160">DNA</text></g></svg>
    <div class="stack"><div class="bubble">Pernahkah kamu berpikir bahwa buah tomat memiliki DNA? Bagaimana cara memperoleh dan mengamatinya?</div>
    <p class="kicker">1. Apakah buah tomat memiliki DNA?</p><div class="chips" id="q1">${[['ya','Ya, setiap sel hidup tomat memiliki DNA'],['biji','Hanya bijinya'],['tidak','Tidak, hanya hewan yang punya DNA']].map(o=>`<button class="chip ${a.q1===o[0]?(o[0]==='ya'?'good':'bad'):''}" data-v="${o[0]}">${o[1]}</button>`).join('')}</div><p class="reply" id="r1" ${a.q1?'':'hidden'}></p>
    <p class="kicker">2. Prediksi: seperti apa DNA tomat jika berhasil diisolasi?</p><div class="chips" id="q2">${[['heliks','Heliks ganda kecil terlihat jelas'],['endapan','Endapan putih keruh/serabut halus'],['merah','Cairan merah pekat']].map(o=>`<button class="chip ${a.q2===o[0]?'sel':''}" data-v="${o[0]}">${o[1]}</button>`).join('')}</div><p class="reply" id="r2" ${a.q2?'':'hidden'}>Prediksimu disimpan. Kita buktikan di slide 18.</p></div></div>`;
  const R1 = {ya:'Tepat. Setiap sel hidup tomat menyimpan DNA, terutama di inti sel.', biji:'Kurang tepat. Bukan hanya biji: setiap sel hidup daging buah juga memiliki DNA.', tidak:'Keliru. Tumbuhan, hewan, jamur, dan bakteri semuanya memiliki DNA.'};
  if (a.q1) $('#r1').textContent = R1[a.q1];
  $$('#q1 .chip').forEach(c => c.onclick = () => { a.q1 = c.dataset.v; store.set('ap', a); $$('#q1 .chip').forEach(x => x.className = 'chip' + (x===c ? (c.dataset.v==='ya'?' good':' bad') : '')); $('#r1').hidden = false; $('#r1').textContent = R1[a.q1]; c.dataset.v==='ya'?sfx.ok():sfx.bad(); });
  $$('#q2 .chip').forEach(c => c.onclick = () => { a.q2 = c.dataset.v; store.set('ap', a); $$('#q2 .chip').forEach(x => x.classList.toggle('sel', x===c)); $('#r2').hidden = false; });
} });
// 3
let goalN = 0;
SL.push({ title:'Tujuan Pembelajaran', render(el){ const G = ['Memahami konsep dasar DNA.','Menjelaskan prinsip isolasi DNA.','Mengidentifikasi alat dan bahan beserta fungsinya.','Memahami dan melakukan tahapan praktikum.','Menerapkan keselamatan kerja di laboratorium.','Menganalisis hasil pengamatan isolasi DNA tumbuhan.'];
  el.innerHTML = `<h2 class="ribbon">Tujuan Pembelajaran</h2><div class="split"><div class="panel paper"><p class="lead-b">Setelah praktikum ini, kamu diharapkan mampu:</p><ul class="checks" id="goals">${G.map(g=>`<li>${g}</li>`).join('')}</ul>
    <div class="center"><button class="btn-y" id="goalB">Tampilkan tujuan berikutnya ▶</button></div></div>
    <svg viewBox="0 0 200 200" class="av"><circle cx="100" cy="100" r="84" fill="#ef4b4b" stroke="#1b2f6b" stroke-width="5"/><circle cx="100" cy="100" r="58" fill="#fff"/><circle cx="100" cy="100" r="32" fill="#ef4b4b"/><circle cx="100" cy="100" r="10" fill="#fff"/><path d="M100,100 L176,24" stroke="#1b2f6b" stroke-width="6"/><path d="M160,22 L180,20 L178,40" fill="none" stroke="#1b2f6b" stroke-width="6"/></svg></div>`;
  const li = $$('#goals li'); li.forEach((l,i) => l.classList.toggle('on', i<goalN));
  const b = $('#goalB'); const upd = () => { b.disabled = goalN>=G.length; b.textContent = goalN>=G.length ? 'Semua tujuan ditampilkan ✓' : 'Tampilkan tujuan berikutnya ▶'; };
  upd(); b.onclick = () => { if (goalN<G.length){ li[goalN].classList.add('on'); goalN++; sfx.pop(); upd(); } };
} });
// 4
SL.push({ title:'Mengenal DNA', render(el){ el.innerHTML = `<h2 class="ribbon">Mengenal DNA</h2><div class="split"><div class="art">${helixAnim}<p class="note" style="text-align:center;margin-top:6px">Ketuk bagian heliks: fosfat (biru), gula (ungu), basa (warna-warni), ikatan hidrogen (garis putus-putus).</p></div>
  <div class="stack"><div class="bubble"><b>DNA (asam deoksiribonukleat)</b> adalah molekul yang menyimpan informasi genetik makhluk hidup dan berperan dalam pewarisan sifat. Bentuknya <b>heliks ganda</b>: dua untai yang saling berpilin.</div>
  <div class="infobox" id="hxInfo"><h3>Ketuk salah satu bagian</h3><p style="margin:0">Setiap bagian heliks punya peran berbeda.</p></div>
  <div class="facts"><span>Satu molekul DNA ± 2 nm lebarnya</span><span>Tidak terlihat oleh mata telanjang</span></div></div></div>`;
  $$('#dnaSvg .hot').forEach(h => h.onclick = () => { const k = h.dataset.h; $$('#dnaSvg .hot').forEach(x => x.classList.toggle('on', x.dataset.h===k)); $('#hxInfo').innerHTML = `<h3>${HX[k][0]}</h3><p style="margin:0">${HX[k][1]}</p>`; sfx.pop(); });
} });
// 5
SL.push({ title:'Struktur Sel Tumbuhan', render(el){ el.innerHTML = `<h2 class="ribbon">Struktur Sel Tumbuhan</h2><div class="split"><svg viewBox="0 0 320 240" class="illus" id="cellSvg">
    <g class="hot" data-c="dinding"><rect x="20" y="16" width="280" height="208" rx="20" fill="#d3f9d8" stroke="#2f7d1f" stroke-width="12"/></g>
    <g class="hot" data-c="membran"><rect x="34" y="30" width="252" height="180" rx="12" fill="#fff9f0" stroke="#e8590c" stroke-width="4" stroke-dasharray="7 4"/></g>
    <g class="hot" data-c="vakuola"><ellipse cx="200" cy="124" rx="70" ry="58" fill="#d0ebff" stroke="#74c0fc" stroke-width="3"/></g>
    <g class="hot" data-c="inti"><circle cx="90" cy="80" r="30" fill="#d0bfff" stroke="#5f3dc4" stroke-width="4"/><circle cx="94" cy="76" r="9" fill="#7048e8"/><path d="M74,88 C80,70 92,98 104,84" stroke="#1c55b0" stroke-width="2" fill="none"/></g>
    <g class="hot" data-c="mito"><ellipse cx="80" cy="160" rx="22" ry="11" fill="#ffc9c9" stroke="#c92a2a" stroke-width="3"/><path d="M62,160 C68,152 74,168 80,158 C86,150 92,168 98,160" stroke="#c92a2a" stroke-width="2" fill="none"/></g>
    <g class="hot" data-c="plastida"><ellipse cx="128" cy="186" rx="18" ry="10" fill="#ff922b" stroke="#d9480f" stroke-width="3"/><ellipse cx="260" cy="56" rx="16" ry="9" fill="#ff922b" stroke="#d9480f" stroke-width="3"/></g>
    <g font-family="Nunito" font-weight="800" font-size="11" fill="#1b2f6b" pointer-events="none"><text x="200" y="128" text-anchor="middle">vakuola</text><text x="90" y="124" text-anchor="middle">inti</text><text x="80" y="185" text-anchor="middle">mitokondria</text><text x="236" y="40">plastida</text></g></svg>
    <div class="stack"><div class="bubble">DNA pada sel tumbuhan <b>terutama terdapat di dalam inti sel</b>. DNA juga ditemukan pada <b>mitokondria</b> dan <b>plastida</b> (kloroplas; pada buah tomat matang berupa kromoplas).</div>
    <div class="task" id="cellTask">👉 Tantangan: ketuk bagian sel tempat sebagian besar DNA disimpan.</div>
    <div class="infobox" id="cellInfo"><h3>Ketuk bagian sel</h3><p style="margin:0">Setiap bagian akan menampilkan keterangan.</p></div></div></div>`;
  $$('#cellSvg .hot').forEach(h => h.onclick = ev => { ev.stopPropagation(); const k = h.dataset.c, c = CELL[k]; $$('#cellSvg .hot').forEach(x => x.classList.toggle('on', x===h));
    $('#cellInfo').innerHTML = `<h3>${c[0]} ${c[2]===true?'🧬 DNA utama':c[2]==='sec'?'🧬 ada DNA':''}</h3><p style="margin:0">${c[1]}</p>`;
    if (c[2]===true){ $('#cellTask').className = 'task ok'; $('#cellTask').textContent = '✓ Tepat! Inti sel adalah lokasi utama DNA.'; sfx.ok(); } else sfx.pop(); });
} });
// 6
let flowN = 0;
SL.push({ title:'Pengertian Isolasi DNA', render(el){ const F = [['Jaringan tomat','<use href="#tomato" x="2" y="2" width="60" height="60"/>'],['Bubur tomat','<path d="M6,24 L58,24 C58,44 46,58 32,58 C18,58 6,44 6,24 Z" fill="#e9ecef" stroke="#1b2f6b" stroke-width="3"/><ellipse cx="32" cy="34" rx="22" ry="6" fill="#ff7a5c"/>'],['Ekstrak (lisis sel)','<path d="M14,6 L14,54 C14,58 18,60 22,60 L42,60 C46,60 50,58 50,54 L50,6" fill="#f8f9fa" stroke="#1b2f6b" stroke-width="3"/><rect x="16" y="26" width="32" height="32" fill="#ff9e80"/>'],['Filtrat','<path d="M14,6 L14,54 C14,58 18,60 22,60 L42,60 C46,60 50,58 50,54 L50,6" fill="#f8f9fa" stroke="#1b2f6b" stroke-width="3"/><rect x="16" y="30" width="32" height="28" fill="#ffd8a8"/>'],['Endapan DNA','<path d="M24,4 L40,4 L40,50 C40,62 24,62 24,50 Z" fill="#f8f9fa" stroke="#1b2f6b" stroke-width="3"/><rect x="26" y="34" width="12" height="22" fill="#ffd8a8"/><rect x="26" y="16" width="12" height="18" fill="#d0ebff"/><path d="M27,33 c3,-5 5,2 9,-3" stroke="#fff" stroke-width="3" fill="none"/>']];
  el.innerHTML = `<h2 class="ribbon">Pengertian Isolasi DNA</h2><div class="bubble" style="margin-bottom:14px"><b>Isolasi DNA</b> adalah proses memisahkan DNA dari komponen sel lainnya (protein, lipid, karbohidrat, sisa jaringan) agar dapat diamati atau dianalisis.</div>
    <div class="flow3" id="flow">${F.map((f,i)=>`<div class="fstep ${i<flowN?'on':''}"><svg viewBox="0 0 64 64">${f[1]}</svg>${i+1}. ${f[0]}</div>`).join('')}</div>
    <div class="center"><button class="btn-y" id="flowB"></button></div>`;
  const b = $('#flowB'), steps = $$('#flow .fstep'); const upd = () => { b.textContent = flowN>=F.length ? 'Ulangi diagram ⟲' : 'Tampilkan tahap berikutnya ▶'; };
  upd(); b.onclick = () => { if (flowN>=F.length){ flowN = 0; steps.forEach(s => s.classList.remove('on')); } else { steps[flowN].classList.add('on'); flowN++; sfx.pop(); } upd(); };
} });
// 7
SL.push({ title:'Prinsip Dasar Isolasi DNA', render(el){ const P = [['1. Lisis sel','<svg viewBox="0 0 160 100"><circle cx="50" cy="50" r="34" fill="none" stroke="#e8590c" stroke-width="5" stroke-dasharray="8 6"/><circle cx="50" cy="50" r="14" fill="#d0bfff" stroke="#5f3dc4" stroke-width="3"/><path d="M96,50 L120,50" stroke="#1b2f6b" stroke-width="4"/><path d="M114,42 L124,50 L114,58" fill="none" stroke="#1b2f6b" stroke-width="4"/><path d="M128,40 c6,-8 12,8 18,0 c6,-8 12,8 12,0" stroke="#2f7be6" stroke-width="4" fill="none"/></svg>','<b>Detergen</b> melarutkan lipid pada membran sel dan membran inti sehingga isi sel, termasuk DNA, keluar. <b>Garam</b> membantu: ion Na⁺ mengurangi tolakan muatan negatif antarmolekul DNA. Sebelumnya, jaringan dihancurkan agar dinding sel robek.'],
    ['2. Penyaringan','<svg viewBox="0 0 160 100"><path d="M30,10 L130,10 L92,56 L92,80 L68,80 L68,56 Z" fill="#f8f9fa" stroke="#1b2f6b" stroke-width="4" stroke-linejoin="round"/><path d="M38,14 L122,14 L80,62 Z" fill="#fff" stroke="#adb5bd" stroke-width="3"/><ellipse cx="80" cy="22" rx="30" ry="6" fill="#d9480f" opacity=".7"/><circle cx="80" cy="90" r="5" fill="#ffd8a8" stroke="#e8590c"/></svg>','Kertas saring atau kain kasa menahan <b>ampas</b> (sisa jaringan dan dinding sel). Cairan yang lolos disebut <b>filtrat</b> dan mengandung DNA terlarut.'],
    ['3. Pengendapan','<svg viewBox="0 0 160 100"><path d="M66,6 L94,6 L94,80 C94,98 66,98 66,80 Z" fill="#f8f9fa" stroke="#1b2f6b" stroke-width="4"/><rect x="69" y="54" width="22" height="34" fill="#ffd8a8"/><rect x="69" y="24" width="22" height="30" fill="#d0ebff"/><path d="M71,52 c4,-6 6,3 10,-3 c3,-4 5,1 7,-1" stroke="#fff" stroke-width="3" fill="none"/></svg>','<b>Etanol dingin</b> ditambahkan perlahan. DNA sukar larut dalam etanol sehingga beragregasi dan mengendap di batas lapisan sebagai endapan putih.']];
  el.innerHTML = `<h2 class="ribbon">Prinsip Dasar Isolasi DNA</h2><p class="hint">Ketuk setiap tahapan untuk melihat penjelasannya.</p><div class="cards3">${P.map(p=>`<button class="pcard" aria-expanded="false">${p[1]}<h3>${p[0]}</h3><span class="more">${p[2]}</span></button>`).join('')}</div>`;
  $$('.pcard').forEach(c => c.onclick = () => { c.setAttribute('aria-expanded', c.getAttribute('aria-expanded')!=='true'); sfx.pop(); });
} });
// 8
SL.push({ title:'Mengenal Objek Praktikum', render(el){ const I = { nama:['Nama ilmiah','<i>Solanum lycopersicum</i> L., famili Solanaceae.'], krom:['Kromosom','Diploid dengan 2n = 24 kromosom.'], isi:['Kandungan buah','Sebagian besar air (± 94–95%), gula, asam organik, likopen (pigmen merah), dan pektin.'], cocok:['Mengapa cocok?','Lunak dan mudah dihaluskan, murah, mudah didapat, dan tidak memerlukan alat khusus.'], kendala:['Hal yang perlu diperhatikan','Pektin dan polisakarida lain dapat ikut mengendap bersama DNA, sehingga endapan tampak keruh atau berlendir. Endapan ini <b>bukan DNA murni</b>.'] };
  el.innerHTML = `<h2 class="ribbon">Mengenal Objek Praktikum</h2><div class="split"><svg viewBox="0 0 320 220" class="illus"><use href="#tomato" x="14" y="40" width="130" height="130"/>
    <g transform="translate(230,110)"><circle r="72" fill="#e8432e" stroke="#a3241a" stroke-width="5"/><circle r="60" fill="#ff8a7a"/>${[0,1,2,3].map(k=>`<g transform="rotate(${k*90})"><path d="M0,0 L0,-52 A52,52 0 0 1 36,-36 Z" fill="#ffa8a8" stroke="#e8432e" stroke-width="4"/>${[0,1,2].map(j=>`<ellipse cx="${10+j*8}" cy="${-26-j*6}" rx="3" ry="5" fill="#fff3bf" stroke="#d9a400"/>`).join('')}</g>`).join('')}<circle r="10" fill="#ffc9c9"/></g>
    <g font-family="Nunito" font-weight="800" font-size="12" fill="#1b2f6b"><text x="80" y="200" text-anchor="middle">tomat utuh</text><text x="230" y="200" text-anchor="middle">penampang buah</text></g></svg>
    <div class="stack"><div class="bubble">Tomat (<i>Solanum lycopersicum</i>) adalah bahan tumbuhan yang dapat dipakai sebagai sumber DNA dalam praktikum isolasi DNA sederhana.</div>
    <div class="chips" id="infoB">${Object.keys(I).map(k=>`<button class="chip" data-k="${k}">${I[k][0]}</button>`).join('')}</div><div class="infobox" id="tInfo"><h3>Karakteristik sampel</h3><p style="margin:0">Ketuk tombol di atas.</p></div></div></div>`;
  $$('#infoB .chip').forEach(c => c.onclick = () => { $$('#infoB .chip').forEach(x => x.classList.toggle('sel', x===c)); const i = I[c.dataset.k]; $('#tInfo').innerHTML = `<h3>${i[0]}</h3><p style="margin:0">${i[1]}</p>`; sfx.pop(); });
} });
// 9 & 10
function catalog(list, kind){ return { title: kind==='alat'?'Alat Praktikum':'Bahan Praktikum', render(el){ const seen = new Set(store.get('seen-'+kind, []));
  el.innerHTML = `<h2 class="ribbon">${kind==='alat'?'Alat Praktikum':'Bahan Praktikum'}</h2><div class="split wide"><div><p class="hint">Ketuk ${kind==='alat'?'gambar alat':'setiap bahan'} untuk melihat ${kind==='alat'?'nama, jumlah, dan fungsinya':'takaran dan fungsinya'}. <span class="counter" id="cnt"></span></p>
    <div class="grid-tools">${list.map((t,i)=>`<button class="tcard ${seen.has(i)?'seen':''}" data-i="${i}">${IC[t[0]]}${t[1]}</button>`).join('')}</div></div>
    <div class="stack"><div class="infobox" id="catInfo"><h3>${kind==='alat'?'Pilih alat':'Pilih bahan'}</h3><p style="margin:0">${kind==='alat'?'Setiap alat membantu proses penghancuran, pencampuran, penyaringan, atau pengamatan DNA.':'Detergen melisiskan membran, garam mendukung agregasi DNA, dan etanol dingin membantu presipitasi.'}</p></div>
    ${kind==='bahan'?'<p class="note">Takaran ini adalah rancangan awal dan perlu diuji lewat praktikum pendahuluan sebelum dijadikan protokol tetap.</p>':''}</div></div>`;
  const cnt = () => $('#cnt').textContent = `(${seen.size}/${list.length} dikenali)`; cnt();
  $$('.tcard').forEach(c => c.onclick = () => { const i = +c.dataset.i, t = list[i]; seen.add(i); store.set('seen-'+kind, [...seen]); c.classList.add('seen'); cnt(); sfx.pop();
    $('#catInfo').innerHTML = `<div style="display:flex;gap:10px;align-items:center"><span style="width:64px;flex:none">${IC[t[0]]}</span><h3>${t[1]}</h3></div><dl><dt>${kind==='alat'?'Jumlah':'Takaran'}</dt><dd>${t[2]}</dd><dt>Fungsi</dt><dd>${t[3]}</dd></dl>`; });
} }; }
SL.push(catalog(TOOLS,'alat')); SL.push(catalog(MATS,'bahan'));
// 11
SL.push({ title:'Keselamatan Kerja', locked: () => K3.size<K3L.length, lockMsg:'Centang semua poin keselamatan kerja sebelum memulai praktikum.', render(el){
  el.innerHTML = `<h2 class="ribbon">Keselamatan Kerja</h2><div class="split rev"><div class="stack"><p class="hint">Centang setiap poin sebagai komitmenmu sebelum memulai praktikum.</p><ul class="k3list">${K3L.map((k,i)=>`<li><label><input type="checkbox" data-i="${i}" ${K3.has(i)?'checked':''}> ${k}</label></li>`).join('')}</ul><p class="reply" id="k3msg"></p></div>
    <svg viewBox="0 0 160 170" class="av" id="k3av"></svg></div>`;
  const draw = () => { const coat = K3.has(0); $('#k3av').innerHTML = `<path d="M30,170 C30,128 50,112 80,112 C110,112 130,128 130,170 Z" fill="${coat?'#fff':'#4dabf7'}" stroke="#1b2f6b" stroke-width="4"/>${coat?'<path d="M68,114 L80,138 L92,114" fill="#4dabf7" stroke="#1b2f6b" stroke-width="3"/><path d="M80,138 L80,170" stroke="#1b2f6b" stroke-width="3"/>':''}<circle cx="34" cy="152" r="11" fill="${coat?'#74c0fc':'#ffd2ad'}" stroke="#1b2f6b" stroke-width="3"/><circle cx="126" cy="152" r="11" fill="${coat?'#74c0fc':'#ffd2ad'}" stroke="#1b2f6b" stroke-width="3"/><rect x="72" y="98" width="16" height="16" fill="#ffd2ad"/><circle cx="80" cy="66" r="36" fill="#ffd2ad" stroke="#1b2f6b" stroke-width="4"/><path d="M44,66 C40,32 66,22 84,26 C106,28 118,44 114,66 C108,52 100,46 90,46 L86,38 L80,48 L72,40 L66,50 C56,50 50,56 46,68 Z" fill="#1d1f2b"/>${K3.size===K3L.length?'<rect x="54" y="58" width="24" height="18" rx="8" fill="#d0f4ff" stroke="#1b2f6b" stroke-width="3"/><rect x="82" y="58" width="24" height="18" rx="8" fill="#d0f4ff" stroke="#1b2f6b" stroke-width="3"/><path d="M78,66 L82,66" stroke="#1b2f6b" stroke-width="3"/>':''}<ellipse cx="66" cy="68" rx="4" ry="5.5" fill="#1d1f2b"/><ellipse cx="94" cy="68" rx="4" ry="5.5" fill="#1d1f2b"/><path d="M70,84 Q80,${K3.size===K3L.length?94:88} 90,84" fill="none" stroke="#1b2f6b" stroke-width="3" stroke-linecap="round"/>`;
    $('#k3msg').textContent = K3.size===K3L.length ? '✓ Semua poin keselamatan sudah kamu sepakati. Praktikum siap dimulai!' : `${K3.size}/${K3L.length} poin dicentang.`; };
  draw(); $$('.k3list input').forEach(i => i.onchange = () => { i.checked ? K3.add(+i.dataset.i) : K3.delete(+i.dataset.i); store.set('k3', [...K3]); if (K3.size===K3L.length) sfx.ok(); draw(); updateNext(); });
} });
// 12
SL.push(Object.assign({ title:'Persiapan Sampel Tomat' }, labSlide({ ribbon:'Persiapan Sampel Tomat', tray:['tomat','air','pisau','mortar'], names:{tomat:'Tomat matang ±50 g', air:'Air bersih (cuci)', pisau:'Pisau & talenan', mortar:'Mortar & alu'},
  wrong:{ mortar:'Belum saatnya menghaluskan. Cuci dan potong tomat dulu.' },
  sci:'<b>Mengapa dicuci dan dipotong?</b> Mencuci menghilangkan kotoran dan sisa pestisida. Potongan kecil memudahkan penghancuran jaringan pada langkah berikutnya.',
  steps:[
    { t:'Ambil ± 50 gram tomat matang.', items:['tomat'], done:()=>L.sample.picked, act(){ L.sample.picked = true; toast('Tomat diletakkan di bak cuci.'); } },
    { t:'Cuci tomat dengan air bersih (ketuk 3×).', items:['air'], done:()=>L.sample.washN>=3, act(){ L.sample.washN++; sfx.pour(); if (L.sample.washN>=3) toast('Tomat sudah bersih.'); } },
    { t:'Potong tomat kecil-kecil dengan pisau di atas talenan (ketuk 6×). Arahkan pisau menjauhi jari!', items:['pisau'], done:()=>L.sample.cut>=6, act(){ if (L.sample.cut===0) toast('Hati-hati! Arahkan mata pisau menjauhi jari.', 'warn'); L.sample.cut++; sfx.chop(); if (L.sample.cut>=6) toast('Tomat terpotong kecil-kecil (± 50 g).'); } },
  ], draw: drawS12 })));
// 13
SL.push(Object.assign({ title:'Penghancuran Jaringan Tomat' }, labSlide({ ribbon:'Penghancuran Jaringan Tomat', tray:['mortar','alu','pengaduk','beker'], names:{mortar:'Mortar', alu:'Alu', pengaduk:'Batang pengaduk', beker:'Gelas beker'},
  wrong:{ pengaduk:'Batang pengaduk tidak cukup kuat untuk menghancurkan jaringan. Gunakan mortar dan alu.', beker:'Gelas beker bukan alat penghancur. Gunakan mortar dan alu.' },
  sci:'<b>Mengapa dihaluskan?</b> Penghancuran mekanik merobek dinding sel (selulosa dan pektin) dan memperluas permukaan jaringan sehingga larutan ekstraksi mudah menjangkau sel.',
  zoom: zoomCells,
  steps:[
    { t:'Masukkan potongan tomat ke mortar.', items:['mortar'], done:()=>L.grind.inMortar, act(){ L.grind.inMortar = true; toast('Potongan tomat masuk ke mortar.'); } },
    { t:'Haluskan dengan alu (gerakan melingkar) hingga menjadi bubur.', items:['alu'], done:()=>L.grind.done, act(id, ctx){
      const pad = circlePad(ctx.wb, `<h3>Menghaluskan dengan alu</h3><p>Gerakkan jari melingkar untuk menggerus tomat.</p><div class="pad"><span class="dot" style="left:calc(50% - 13px);top:8px"></span></div><div class="prog"><i style="width:${L.grind.v}%"></i></div><p class="gv">Kehalusan ${Math.round(L.grind.v)}%</p><div class="choice"><button class="mini" data-k>Gerus (tombol)</button><button class="mini y" data-s>Selesai menghaluskan</button></div>`,
        da => { L.grind.v = Math.min(100, L.grind.v + da*3.2); pad.el.querySelector('.prog i').style.width = L.grind.v+'%'; pad.el.querySelector('.gv').textContent = `Kehalusan ${Math.round(L.grind.v)}%`; if (L.grind.v>=100) pad.close(); },
        () => { L.grind.done = true; saveLab(); toast(L.grind.v>=90 ? 'Tomat menjadi bubur halus.' : `Kehalusan baru ${Math.round(L.grind.v)}%. Banyak sel belum pecah.`, L.grind.v>=90?'ok':'warn'); ctx.paint(); });
      pad.el.querySelector('[data-k]').onclick = () => { L.grind.v = Math.min(100, L.grind.v+20); pad.el.querySelector('.prog i').style.width = L.grind.v+'%'; pad.el.querySelector('.gv').textContent = `Kehalusan ${Math.round(L.grind.v)}%`; if (L.grind.v>=100) pad.close(); };
      pad.el.querySelector('[data-s]').onclick = () => pad.close(); } },
  ], draw: drawS13 })));
// 14
function spoonChoice(what, right, cb){
  dialog(`Takar ${what}`, `<p>Pilih takaran sendok ukur untuk ${what}:</p>`, [['¼ sdt', () => { closeDlg(); cb('¼ sdt'); }], ['½ sdt', () => { closeDlg(); cb('½ sdt'); }], ['1 sdt', () => { closeDlg(); cb('1 sdt'); }], ['1 sdm', () => { closeDlg(); cb('1 sdm'); }]]);
}
const SP = {'¼ sdt':1.25,'½ sdt':2.5,'1 sdt':5,'1 sdm':15};
SL.push(Object.assign({ title:'Pembuatan Larutan Ekstraksi' }, labSlide({ ribbon:'Pembuatan Larutan Ekstraksi', tray:['beker','ukur','garam','deterjen','pengaduk','etanol'], names:{beker:'Gelas beker', ukur:'Gelas ukur + air', garam:'Garam (sendok ukur)', deterjen:'Detergen cair (sendok ukur)', pengaduk:'Batang pengaduk', etanol:'Etanol'},
  wrong:{ etanol:'Etanol baru dipakai pada tahap pengendapan, bukan untuk larutan ekstraksi.' },
  sci:'<b>Komposisi larutan ekstraksi:</b> 100 mL air, ½ sdt garam, dan 1 sdm detergen cair. Aduk <b>perlahan</b> agar tidak berbusa berlebihan.',
  steps:[
    { t:'Siapkan gelas beker.', items:['beker'], done:()=>L.sol.beaker, act(){ L.sol.beaker = true; toast('Gelas beker siap.'); } },
    { t:'Ukur 100 mL air dengan gelas ukur, lalu tuang ke gelas beker.', items:['ukur'], done:()=>L.sol.waterDone, act(id, ctx){
      pourPanel(ctx.wb, { title:'Mengukur air dengan gelas ukur', note:'Tahan tombol untuk mengisi gelas ukur. Lepaskan tepat di garis 100 mL (baca meniskus sejajar mata).', unit:'mL', target:100, lo:95, hi:105, max:130, rate:1.1,
        onDone:(v, ok) => { L.sol.water = Math.round(v); L.sol.waterDone = true; if (ok) toast(`${Math.round(v)} mL air dituang ke gelas beker.`); saveLab(); ctx.paint(); } }); } },
    { t:'Tambahkan ½ sendok teh garam.', items:['garam'], free:true, done:()=>!!L.sol.salt, act(id, ctx){ if (!L.sol.waterDone) return toast('Masukkan air dulu.', 'warn');
      spoonChoice('garam', '½ sdt', ch => { L.sol.salt = ch==='½ sdt' ? 'ok' : SP[ch]<2.5 ? 'kurang' : 'lebih'; toast(ch==='½ sdt' ? 'Garam ½ sdt ditambahkan.' : `Kamu menakar ${ch}. Takaran anjuran ½ sdt.`, ch==='½ sdt'?'ok':'warn'); saveLab(); ctx.paint(); }); } },
    { t:'Tambahkan 1 sendok makan detergen cair.', items:['deterjen'], free:true, done:()=>!!L.sol.det, act(id, ctx){ if (!L.sol.waterDone) return toast('Masukkan air dulu.', 'warn');
      spoonChoice('detergen', '1 sdm', ch => { L.sol.det = ch==='1 sdm' ? 'ok' : SP[ch]<15 ? 'kurang' : 'lebih'; toast(ch==='1 sdm' ? 'Detergen 1 sdm ditambahkan.' : `Kamu menakar ${ch}. Takaran anjuran 1 sdm.`, ch==='1 sdm'?'ok':'warn'); saveLab(); ctx.paint(); }); } },
    { t:'Aduk perlahan hingga merata (hindari busa).', items:['pengaduk'], done:()=>L.sol.stir>=100, act(id, ctx){ stirPanel(ctx.wb, 'Mengaduk larutan ekstraksi', L.sol, 'stir', 'foam', 5, () => { if (!L.sol.foam) toast('Larutan ekstraksi tercampur rata tanpa busa.'); ctx.paint(); }); } },
  ], draw: drawS14 })));
// 15
SL.push(Object.assign({ title:'Proses Ekstraksi Sel' }, labSlide({ ribbon:'Proses Ekstraksi Sel', tray:['larutan','pengaduk','timer','etanol'], names:{larutan:'Larutan ekstraksi', pengaduk:'Batang pengaduk', timer:'Pengatur waktu', etanol:'Etanol'}, 
  wrong:{ etanol:'Etanol belum diperlukan. Sel harus dilisiskan dulu.' },
  sci:'<b>Penjelasan ilmiah:</b> detergen melarutkan membran sel dan membran inti sehingga DNA dilepaskan ke campuran. Campuran cukup diaduk perlahan sebentar lalu <b>didiamkan</b> 5–10 menit, karena pengadukan lama dapat mematahkan DNA.',
  zoom: zoomMembrane,
  steps:[
    { t:'Tuang ± 50 mL larutan ekstraksi ke bubur tomat.', items:['larutan'], done:()=>L.ext.poured, act(id, ctx){
      pourPanel(ctx.wb, { title:'Menuang larutan ekstraksi', note:'Tahan tombol untuk menuang. Berhenti di sekitar 50 mL.', unit:'mL', target:50, lo:40, hi:60, max:100, rate:1,
        onDone:(v, ok) => { L.ext.vol = Math.round(v); L.ext.poured = true; if (ok) toast(`${Math.round(v)} mL larutan ekstraksi ditambahkan.`); saveLab(); ctx.paint(); } }); } },
    { t:'Aduk perlahan sebentar.', items:['pengaduk'], done:()=>L.ext.stir>=100, act(id, ctx){ stirPanel(ctx.wb, 'Mengaduk campuran', L.ext, 'stir', 'foam', 6, () => { if (!L.ext.foam) toast('Campuran teraduk perlahan.'); ctx.paint(); }); } },
    { t:'Diamkan 10 menit agar lisis sel berlangsung.', items:['timer'], done:()=>L.ext.waited, async act(id, ctx){ if (L.ext.waiting) return; L.ext.waiting = true; ctx.paint();
      for (let m=2;m<=10;m+=2){ toast(`⏱ ${m} menit…`, 'warn'); await sleep(320); } L.ext.waiting = false; L.ext.waited = true; saveLab(); toast('Lisis selesai: DNA terlepas ke campuran.'); ctx.paint(); } },
  ], draw: drawS15 })));
// 16
SL.push(Object.assign({ title:'Penyaringan Ekstrak' }, labSlide({ ribbon:'Penyaringan Ekstrak', tray:['beker','corong','saring','campuran'], names:{beker:'Gelas beker kosong', corong:'Corong', saring:'Kertas saring', campuran:'Campuran ekstrak'}, icon:{},
  sci:'<b>Penjelasan ilmiah:</b> penyaringan memisahkan sisa jaringan tumbuhan (ampas) dari cairan ekstrak. Cairan yang tertampung disebut <b>filtrat</b>.',
  steps:[
    { t:'Siapkan gelas beker kosong sebagai penampung.', items:['beker'], done:()=>L.filt.beaker2, act(){ L.filt.beaker2 = true; toast('Gelas beker penampung siap.'); } },
    { t:'Pasang corong di atas gelas beker.', items:['corong'], done:()=>L.filt.funnel, act(){ L.filt.funnel = true; toast('Corong terpasang.'); } },
    { t:'Lipat dan letakkan kertas saring di dalam corong.', items:['saring'], done:()=>L.filt.paper, act(){ L.filt.paper = true; toast('Kertas saring terpasang.'); } },
    { t:'Tuang campuran ke corong, tampung filtratnya.', items:['campuran'], done:()=>L.filt.done, async act(id, ctx){ if (L.filt.vol>0) return;
      for (let i=1;i<=10;i++){ L.filt.vol = i*4; sfx.pour(); ctx.paint(); await sleep(140); } L.filt.done = true; saveLab(); toast('Filtrat tertampung (± 40 mL). Ampas tertahan di kertas saring.'); ctx.paint(); } },
  ], draw: drawS16 })));
// 17
SL.push(Object.assign({ title:'Penambahan Alkohol Dingin' }, labSlide({ ribbon:'Penambahan Alkohol Dingin', tray:['rak','tabung','pipet','es','penjepit','etanol','kocok','spiritus'], names:{rak:'Rak tabung', tabung:'Tabung reaksi', pipet:'Pipet tetes', es:'Wadah es (dinginkan etanol)', penjepit:'Penjepit tabung', etanol:'Etanol 96%', kocok:'Kocok tabung', spiritus:'Pembakar spiritus'},
  wrong:{ kocok:'Jangan mengocok tabung! Lapisan akan tercampur dan DNA tidak terkumpul di batas lapisan.', spiritus:{k3:true, msg:'⚠ Pelanggaran K3: etanol mudah terbakar. Jauhkan dari api dan sumber panas!'} },
  sci:'<b>Penjelasan ilmiah:</b> etanol mengurangi kelarutan DNA sehingga DNA beragregasi dan mengendap. Etanol dituang <b>perlahan melalui dinding tabung</b> agar membentuk lapisan terpisah di atas filtrat. Jangan mengocok tabung.',
  zoom: zoomPpt,
  steps:[
    { t:'Letakkan rak tabung reaksi.', items:['rak'], done:()=>L.ppt.rack, act(){ L.ppt.rack = true; toast('Rak tabung siap.'); } },
    { t:'Pasang tabung reaksi di rak.', items:['tabung'], done:()=>L.ppt.tube, act(){ L.ppt.tube = true; toast('Tabung reaksi terpasang.'); } },
    { t:'Masukkan ± 5 mL filtrat ke tabung dengan pipet tetes (1 tekan = 1 mL).', items:['pipet'], done:()=>L.ppt.filtDone, act(id, ctx){
      const g = document.createElement('div'); g.className = 'gest'; g.innerHTML = `<h3>Memindahkan filtrat dengan pipet</h3><p>Setiap tekanan memindahkan 1 mL filtrat. Targetnya ± 5 mL.</p><div class="vol"><i style="width:${L.ppt.filtrate*10}%"></i><span class="tgt" style="left:50%"></span></div><p class="pv">${L.ppt.filtrate} mL</p><div class="choice"><button class="holdbtn" data-p>Tekan pipet (+1 mL)</button><button class="mini y" data-d>Selesai</button></div>`;
      ctx.wb.appendChild(g);
      g.querySelector('[data-p]').onclick = () => { if (L.ppt.filtrate>=10) return; L.ppt.filtrate++; sfx.pour(); g.querySelector('.vol i').style.width = L.ppt.filtrate*10+'%'; g.querySelector('.pv').textContent = L.ppt.filtrate+' mL'; };
      g.querySelector('[data-d]').onclick = () => { if (!L.ppt.filtrate) return toast('Belum ada filtrat yang dipindahkan.', 'warn'); g.remove(); L.ppt.filtDone = true; saveLab();
        toast(L.ppt.filtrate>=4 && L.ppt.filtrate<=6 ? `${L.ppt.filtrate} mL filtrat di tabung.` : `${L.ppt.filtrate} mL filtrat (anjuran ± 5 mL).`, L.ppt.filtrate>=4 && L.ppt.filtrate<=6 ? 'ok':'warn'); ctx.paint(); }; } },
    { t:'Dinginkan etanol di wadah es (sebelum dituang).', items:['es'], free:true, done:()=>L.ppt.iced || L.ppt.poured, act(){ L.ppt.iced = true; toast('Etanol didinginkan di wadah es.'); } },
    { t:'Pegang dan miringkan tabung dengan penjepit tabung.', items:['penjepit'], free:true, done:()=>L.ppt.clamp || L.ppt.poured, act(){ L.ppt.clamp = true; toast('Tabung dimiringkan dengan penjepit.'); } },
    { t:'Tuang ± 5 mL etanol perlahan melalui dinding tabung.', items:['etanol'], done:()=>L.ppt.poured, act(id, ctx){
      if (!L.ppt.filtDone) return toast('Masukkan filtrat ke tabung dulu.', 'warn');
      if (!L.ppt.iced) toast('Etanol belum didinginkan! Pengendapan akan lebih sedikit.', 'warn');
      L.ppt.cold = L.ppt.iced;
      pourPanel(ctx.wb, { title:'Menuang etanol', note:`Atur kemiringan botol lalu tahan tombol. ${L.ppt.clamp?'Tabung sudah dimiringkan, jadi etanol mudah mengalir di dinding tabung.':'Tabung tegak: etanol lebih mudah jatuh langsung dan tercampur.'}`, unit:'mL', target: L.ppt.filtrate, lo: L.ppt.filtrate*.8, hi: L.ppt.filtrate*1.5, max: L.ppt.filtrate*2, tilt:true, mixObj:L.ppt, mixKey:'mixed', mixAt: L.ppt.clamp?55:40, rate:.9,
        onDone:(v) => { L.ppt.eth = Math.round(v*10)/10; L.ppt.poured = true; saveLab(); if (!L.ppt.mixed) toast('Terbentuk dua lapisan: etanol di atas, filtrat di bawah.'); ctx.paint(); } }); } },
  ], draw: drawS17 })));
// 18
SL.push({ title:'Pengamatan Hasil Isolasi DNA', locked: () => !L.obs.waited || ['warna','bentuk','letak','jumlah'].some(k => !L.obs.table[k]), lockMsg:'Diamkan tabung, amati dengan lup, lalu lengkapi tabel pengamatan.', render(el){
  if (!L.ppt.poured){ el.innerHTML = `<h2 class="ribbon">Pengamatan Hasil Isolasi DNA</h2><div class="panel paper"><p><b>Belum ada sampel untuk diamati.</b> Selesaikan langkah praktikum di slide 12–17 dulu.</p><button class="btn-y" id="toLab">Ke slide 12 ▶</button></div>`; $('#toLab').onclick = () => show(12); return; }
  const c = calc(), p = L.ppt, n = L.obs.waited ? Math.round(c.prec/8) : 0, m = p.mixed||p.shaken;
  const inner = `<rect x="0" y="0" width="200" height="260" fill="#f8fbff"/>
    <path d="M80,10 L80,220 C80,252 120,252 120,220 L120,10" fill="#f8f9fa" stroke="#1b2f6b" stroke-width="4"/>
    <path d="M83,140 L117,140 L117,220 C117,246 83,246 83,220 Z" fill="${m?'#ffe8d6':'#ffd8a8'}"/><rect x="83" y="60" width="34" height="80" fill="${m?'#ffe8d6':'#d0ebff'}"/>
    ${Array.from({length:n},(_,i)=>`<path d="M${85+(i%5)*6},${139-(i*7)%34} c2,-6 5,4 7,-4 c2,-4 4,2 5,-1" stroke="#fff" stroke-width="2.2" fill="none"/><path d="M${85+(i%5)*6},${139-(i*7)%34} c2,-6 5,4 7,-4" stroke="#ced4da" stroke-width=".6" fill="none"/>`).join('')}
    ${n>2?`<ellipse cx="100" cy="137" rx="13" ry="4" fill="#fff" opacity=".8"/>${Array.from({length:Math.min(n,12)},(_,i)=>`<circle cx="${88+(i*5)%24}" cy="${133+(i%3)*2}" r=".9" fill="#adb5bd"/>`).join('')}`:''}
    <text x="126" y="64" font-size="9" font-weight="800" fill="#1b2f6b" font-family="Nunito">etanol</text><text x="126" y="200" font-size="9" font-weight="800" fill="#1b2f6b" font-family="Nunito">filtrat</text>`;
  const tube = `<svg viewBox="50 0 110 260" id="obsTube" style="display:block;width:100%;max-height:320px">${inner}</svg>`;
  const T = L.obs.table, ap = store.get('ap', {});
  const opts = { warna:['','Putih keruh','Merah','Kuning bening','Tidak ada endapan'], bentuk:['','Serabut halus/gumpalan lendir','Kristal padat','Heliks ganda terlihat','Tidak ada endapan'], letak:['','Di batas lapisan etanol dan filtrat','Di dasar tabung','Tersebar merata','Tidak ada endapan'], jumlah:['','Banyak','Sedikit','Tidak ada'] };
  el.innerHTML = `<h2 class="ribbon">Pengamatan Hasil Isolasi DNA</h2><div class="sim"><div>
    <div class="workbench loupe-wrap" id="lw">${tube}<div class="loupe" id="lp"><svg id="lensSvg" width="150" height="150" viewBox="80 120 40 40">${inner}</svg></div></div>
    <div class="center row"><button class="btn-y" id="waitO" ${L.obs.waited?'disabled':''}>${L.obs.waited?'✓ Sudah didiamkan':'⏱ Diamkan 3 menit'}</button><span class="note" style="align-self:center">Geser jari/kursor di atas tabung untuk memakai lup.</span></div></div>
    <div class="stack"><table class="obs"><thead><tr><th>Parameter</th><th>Hasil pengamatan</th></tr></thead><tbody>
      ${Object.keys(opts).map(k=>`<tr><td><b>${{warna:'Warna endapan',bentuk:'Bentuk',letak:'Letak',jumlah:'Jumlah'}[k]}</b></td><td><select data-k="${k}" ${L.obs.waited?'':'disabled'}>${opts[k].map(o=>`<option ${T[k]===o?'selected':''} value="${o}">${o||'— pilih —'}</option>`).join('')}</select></td></tr>`).join('')}
    </tbody></table>
    <div class="sci"><b>Penjelasan ilmiah:</b> endapan putih keruh atau serabut halus adalah <b>fraksi yang mengandung DNA</b>, bercampur RNA, protein, dan pektin. Endapan ini belum tentu DNA murni.</div>
    ${ap.q2?`<p class="reply">Prediksimu di slide 2: <b>${{heliks:'heliks ganda terlihat',endapan:'endapan putih keruh/serabut',merah:'cairan merah pekat'}[ap.q2]}</b>. ${ap.q2==='endapan'?'Prediksimu sesuai!':'Hasilnya berbeda: DNA terlihat sebagai endapan, bukan heliks atau cairan merah.'}</p>`:''}
    <button class="btn-y blue" id="repB">Lihat rapor praktikum</button></div></div>${statusHTML()}`;
  $('#waitO').onclick = async () => { $('#waitO').disabled = true; for (let i=1;i<=3;i++){ $('#waitO').textContent = `⏱ ${i} menit…`; await sleep(450); } L.obs.waited = true; saveLab(); toast(calc().prec>=15 ? 'Endapan putih muncul di batas lapisan!' : 'Hampir tidak ada endapan yang terbentuk.', calc().prec>=15?'ok':'warn'); show(18); };
  $$('.obs select').forEach(s => s.onchange = () => { L.obs.table[s.dataset.k] = s.value; saveLab(); updateNext(); });
  $('#repB').onclick = report;
  const lw = $('#lw'), lp = $('#lp'), svg = $('#obsTube'), lens = $('#lensSvg');
  const move = e => { const r = lw.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top; if (x<0||y<0||x>r.width||y>r.height){ lp.classList.remove('on'); return; }
    const pt = svg.createSVGPoint(); pt.x = e.clientX; pt.y = e.clientY; const sp = pt.matrixTransform(svg.getScreenCTM().inverse());
    lp.classList.add('on'); lp.style.left = (x-75)+'px'; lp.style.top = (y-75)+'px'; lens.setAttribute('viewBox', `${sp.x-18} ${sp.y-18} 36 36`); if (!L.obs.zoomed){ L.obs.zoomed = true; saveLab(); } };
  lw.addEventListener('pointermove', move); lw.addEventListener('pointerdown', e => { lw.setPointerCapture?.(e.pointerId); move(e); }); lw.addEventListener('pointerleave', () => lp.classList.remove('on')); lw.addEventListener('pointerup', () => setTimeout(()=>lp.classList.remove('on'), 900));
} });
// 19
const DQ = [
  ['Mengapa buah tomat harus dihancurkan sebelum proses isolasi DNA?','Penghancuran merobek dinding sel dan memperluas permukaan jaringan sehingga larutan ekstraksi dapat menjangkau membran sel.'],
  ['Apa fungsi detergen dalam proses isolasi DNA?','Detergen melarutkan lipid penyusun membran sel dan membran inti sehingga DNA keluar ke larutan.'],
  ['Mengapa garam ditambahkan ke dalam larutan ekstraksi?','Ion Na⁺ dari garam menetralkan sebagian muatan negatif gugus fosfat DNA sehingga tolakan antarmolekul berkurang dan DNA dapat beragregasi saat etanol ditambahkan.'],
  ['Mengapa alkohol harus dalam keadaan dingin?','Pada suhu rendah kelarutan DNA dalam campuran makin kecil sehingga lebih banyak DNA mengendap. Suhu rendah juga memperlambat enzim pemotong DNA (DNase).'],
  ['Mengapa terbentuk endapan putih setelah penambahan alkohol?','DNA sukar larut dalam etanol. Di batas lapisan, jutaan molekul DNA beragregasi sehingga terlihat sebagai endapan atau serabut putih.'],
  ['Apakah endapan putih tersebut merupakan DNA murni?','Bukan. Endapan masih bercampur RNA, protein, dan polisakarida seperti pektin. Kemurnian perlu diuji, misalnya dengan spektrofotometer (rasio A260/A280) atau elektroforesis.'],
];
SL.push({ title:'Diskusi dan Refleksi', render(el){ const A = store.get('disc', {});
  el.innerHTML = `<h2 class="ribbon">Diskusi dan Refleksi</h2><p class="hint">Tulis jawabanmu atau hasil diskusi kelompok, lalu bandingkan dengan jawaban acuan.</p><div class="disc">${DQ.map((q,i)=>`<div class="dq" id="dq${i}"><label for="ta${i}">${i+1}. ${q[0]}</label><textarea id="ta${i}" rows="2" placeholder="Tulis jawabanmu…">${A[i]||''}</textarea><div class="row2"><button class="mini" data-i="${i}">Bandingkan dengan jawaban acuan</button></div><div class="ref"><b>Jawaban acuan:</b> ${q[1]}</div></div>`).join('')}</div>
    <div class="center row"><button class="btn-y" id="copyD">Salin semua jawaban</button></div><p class="note" style="text-align:center">Jawaban tersimpan otomatis di perangkat ini.</p>`;
  DQ.forEach((q,i) => { $('#ta'+i).oninput = e => { A[i] = e.target.value; store.set('disc', A); }; });
  $$('.dq .mini').forEach(b => b.onclick = () => { const i = +b.dataset.i; if (!(A[i]||'').trim()) return toast('Tulis jawabanmu dulu sebelum melihat jawaban acuan.', 'warn'); $('#dq'+i).classList.add('show'); });
  $('#copyD').onclick = () => { const txt = DQ.map((q,i)=>`${i+1}. ${q[0]}\nJawaban: ${A[i]||'-'}`).join('\n\n');
    const ok = () => toast('Jawaban disalin. Tempelkan ke catatan atau kirim ke guru.');
    if (navigator.clipboard?.writeText) navigator.clipboard.writeText(txt).then(ok).catch(() => fallback(txt)); else fallback(txt); };
  function fallback(t){ dialog('Salin jawaban', `<textarea style="width:100%;min-height:200px">${t.replace(/</g,'&lt;')}</textarea><p class="note">Pilih semua teks di atas lalu salin.</p>`, [['Tutup', closeDlg]]); }
} });
// 20
const QUIZ = [
  ['DNA adalah molekul yang berfungsi …',['Menyimpan informasi genetik','Menghasilkan energi sel','Membentuk dinding sel','Mengangkut oksigen'],0,'DNA menyimpan informasi genetik dan berperan dalam pewarisan sifat.'],
  ['Pada sel tumbuhan, sebagian besar DNA terdapat di …',['Vakuola','Inti sel','Dinding sel','Membran sel'],1,'Inti sel adalah lokasi utama DNA; mitokondria dan plastida memiliki DNA dalam jumlah kecil.'],
  ['Fungsi detergen dalam isolasi DNA adalah …',['Mengendapkan DNA','Melarutkan membran sel dan membran inti','Memberi warna pada DNA','Menghancurkan dinding sel selulosa'],1,'Detergen melarutkan lipid penyusun membran.'],
  ['Garam (NaCl) ditambahkan karena ion Na⁺ …',['Mengurangi tolakan muatan negatif antarmolekul DNA','Melarutkan pektin','Memotong DNA','Menaikkan suhu larutan'],0,'Na⁺ menetralkan sebagian muatan negatif gugus fosfat sehingga DNA dapat beragregasi.'],
  ['Etanol dingin digunakan karena …',['DNA mudah larut dalam etanol dingin','DNA sukar larut dalam etanol sehingga mengendap','Etanol membunuh bakteri pada tomat','Etanol memecah membran inti'],1,'DNA sukar larut dalam etanol; suhu dingin memperbanyak endapan.'],
  ['Urutan prosedur isolasi DNA tomat yang benar adalah …',['Penyaringan → penghancuran → lisis → etanol','Penghancuran → lisis dengan larutan ekstraksi → penyaringan → etanol dingin','Etanol → penghancuran → penyaringan → lisis','Lisis → etanol → penghancuran → penyaringan'],1,'Jaringan dihancurkan, sel dilisiskan, campuran disaring, lalu DNA diendapkan dengan etanol.'],
  ['Etanol dituang perlahan melalui dinding tabung agar …',['Etanol cepat menguap','Terbentuk lapisan etanol di atas filtrat','Filtrat menjadi hangat','DNA larut kembali'],1,'Lapisan terpisah memungkinkan DNA beragregasi di batas lapisan.'],
  ['Endapan putih yang terbentuk paling tepat disebut …',['DNA murni','Fraksi endapan yang mengandung DNA','Kristal garam','Protein murni'],1,'Endapan masih bercampur RNA, protein, dan pektin.'],
  ['Jika langkah penambahan detergen dilewati, hasilnya …',['DNA tetap banyak mengendap','DNA hampir tidak keluar dari sel','Endapan berwarna merah','Etanol tidak membentuk lapisan'],1,'Tanpa detergen, membran tidak larut sehingga DNA tetap terkurung.'],
  ['Mengapa DNA hasil isolasi dapat terlihat dengan mata telanjang?',['Satu molekul DNA berukuran sangat besar','Jutaan molekul DNA beragregasi menjadi endapan','DNA tomat berwarna putih terang','Etanol memperbesar molekul DNA'],1,'Satu molekul DNA (± 2 nm) tidak terlihat; agregatnya yang tampak.'],
];
let qi = 0, qres = [];
SL.push({ title:'Kuis dan Penutup', nonext:true, render(el){ el.innerHTML = `<h2 class="ribbon">Kuis dan Penutup</h2><div class="split rev quizwrap"><div class="panel paper" id="quiz"></div><svg class="av" id="buddy" viewBox="0 0 120 120"><use href="#tomato"/></svg></div>`; renderQuiz(); } });
function renderQuiz(){
  const box = $('#quiz'), buddy = $('#buddy'); if (!box) return; buddy.classList.remove('happy','sad');
  if (qi>=QUIZ.length){ const s = Math.round(qres.filter(Boolean).length/QUIZ.length*100), miss = qres.map((r,i)=>r?null:i+1).filter(Boolean); store.set('score', s);
    box.innerHTML = `<p class="kicker">Skor kuis</p><p style="font:800 3rem var(--f-display);color:var(--navy);margin:0">${s}<span style="font-size:1.2rem">/100</span></p>
      <p><b>${s>=80?'Hebat! Kamu memahami isolasi DNA tumbuhan.':s>=60?'Bagus, sedikit lagi!':'Ayo pelajari lagi materinya.'}</b> ${miss.length?`Pelajari lagi soal nomor ${miss.join(', ')}.`:''}</p>
      <div class="center row"><button class="btn-y" id="rq">⟲ Ulang kuis</button><button class="btn-y" id="rm">Ulang materi (slide 4)</button><button class="btn-y" id="rl">Ulang praktikum</button><button class="btn-y blue" id="rr">Rapor praktikum</button></div>
      <p class="reply" style="margin-top:12px">Terima kasih telah belajar! Ingat: hasil isolasi DNA sederhana adalah <b>endapan yang mengandung DNA</b>, bukan heliks ganda yang terlihat.</p>`;
    $('#rq').onclick = () => { qi = 0; qres = []; renderQuiz(); }; $('#rm').onclick = () => show(4); $('#rr').onclick = report;
    $('#rl').onclick = () => dialog('Ulang praktikum?', '<p>Semua langkah praktikum (slide 12–18) akan diulang dari awal.</p>', [['Batal', closeDlg, 'blue'], ['Ulang', () => { closeDlg(); L = freshLab(); saveLab(); show(12); }]]);
    if (s>=80) sfx.win(); return; }
  const q = QUIZ[qi];
  box.innerHTML = `<div class="qhead"><span class="qbadge">Soal ${qi+1} dari ${QUIZ.length}</span><span class="qdots">${QUIZ.map((_,i)=>`<i class="${i<qi?(qres[i]?'ok':'bad'):i===qi?'cur':''}"></i>`).join('')}</span></div>
    <p class="qtext">${q[0]}</p><div class="qopts">${q[1].map((o,j)=>`<button class="qopt" data-j="${j}"><span class="k">${'ABCD'[j]}</span>${o}</button>`).join('')}</div><div id="qfb"></div>`;
  box.querySelectorAll('.qopt').forEach(b => b.onclick = () => { const j = +b.dataset.j, ok = j===q[2]; qres[qi] = ok;
    box.querySelectorAll('.qopt').forEach((x,xi) => { x.disabled = true; if (xi===q[2]) x.classList.add('right'); }); if (!ok) b.classList.add('wrong');
    ok ? sfx.ok() : sfx.bad(); buddy.classList.add(ok?'happy':'sad');
    $('#qfb').innerHTML = `<div class="qexp ${ok?'ok':'bad'}"><b>${ok?'✓ Benar!':'✗ Belum tepat'}</b>${ok?'':`Jawaban yang benar: <b style="display:inline">${q[1][q[2]]}</b>. `}${q[3]}</div><div class="qnav"><button class="btn-y" id="qn">${qi===QUIZ.length-1?'Lihat skor':'Soal berikutnya'} ▶</button></div>`;
    $('#qn').onclick = () => { qi++; renderQuiz(); }; });
}

/* ---------------- rapor praktikum ---------------- */
function report(){
  const c = calc(), s = L.sol, p = L.ppt, fb = [];
  let k3 = K3.size===K3L.length ? 100 : 60; if (K3.size===K3L.length) fb.push(['good','Komitmen keselamatan kerja lengkap.']);
  if (L.k3bad.length){ k3 -= 50*L.k3bad.length; fb.push(['bad','Mendekatkan api ke etanol (pelanggaran K3).']); } k3 = clamp(k3,0,100);
  const pro = clamp(100 - L.wrong.length*10, 0, 100); fb.push(L.wrong.length ? ['bad',`${L.wrong.length} kali memilih alat/bahan yang salah atau tidak berurutan.`] : ['good','Memilih alat dan bahan sesuai urutan prosedur.']);
  let tak = 100;
  if (Math.abs(s.water-100)>5){ tak -= 15; fb.push(['bad',`Air ${s.water} mL (anjuran 100 mL).`]); }
  if (s.salt!=='ok'){ tak -= 15; fb.push(['bad','Takaran garam tidak tepat (anjuran ½ sdt).']); }
  if (s.det!=='ok'){ tak -= 20; fb.push(['bad','Takaran detergen tidak tepat (anjuran 1 sdm).']); }
  if (L.ext.vol<40 || L.ext.vol>60){ tak -= 10; fb.push(['bad',`Larutan ekstraksi ${L.ext.vol} mL (anjuran ± 50 mL).`]); }
  if (p.filtrate<4 || p.filtrate>6){ tak -= 10; fb.push(['bad',`Filtrat ${p.filtrate} mL (anjuran ± 5 mL).`]); }
  if (c.ratio && (c.ratio<.8 || c.ratio>1.5)){ tak -= 15; fb.push(['bad',`Perbandingan etanol : filtrat ${c.ratio.toFixed(1)} : 1 (anjuran ± 1 : 1).`]); }
  if (tak===100) fb.push(['good','Semua takaran tepat.']); tak = clamp(tak,0,100);
  let tek = 100;
  if (L.grind.v<90){ tek -= Math.round((90-L.grind.v)/2); fb.push(['bad',`Tomat hanya ${Math.round(L.grind.v)}% halus.`]); }
  if (s.foam || L.ext.foam){ tek -= 20; fb.push(['bad','Mengaduk terlalu cepat sehingga berbusa.']); }
  if (!p.iced){ tek -= 15; fb.push(['bad','Etanol tidak didinginkan.']); }
  if (!p.clamp){ tek -= 5; fb.push(['bad','Tabung tidak dimiringkan dengan penjepit.']); }
  if (p.mixed){ tek -= 25; fb.push(['bad','Etanol dituang terlalu deras sehingga lapisan tercampur.']); }
  if (L.wrong.includes('kocok')){ tek -= 15; }
  if (tek===100) fb.push(['good','Teknik kerja rapi dan hati-hati.']); tek = clamp(tek,0,100);
  const has = c.prec>=15, key = has ? {warna:'Putih keruh', bentuk:'Serabut halus/gumpalan lendir', letak:'Di batas lapisan etanol dan filtrat', jumlah: c.prec>=55?'Banyak':'Sedikit'} : {warna:'Tidak ada endapan', bentuk:'Tidak ada endapan', letak:'Tidak ada endapan', jumlah:'Tidak ada'};
  const right = Object.keys(key).filter(k => L.obs.table[k]===key[k]).length, obs = right*25;
  fb.push(right===4 ? ['good','Tabel pengamatan sesuai dengan hasil.'] : ['bad',`Tabel pengamatan: ${right} dari 4 sesuai dengan hasil yang terbentuk.`]);
  const total = Math.round((k3+pro+tak+tek+c.prec+obs)/6), grade = total>=85?'A':total>=70?'B':total>=55?'C':'D';
  const rows = [['Keselamatan (K3)',k3,'#ef4b4b'],['Prosedur',pro,'#ff922b'],['Ketepatan takaran',tak,'#fab005'],['Teknik kerja',tek,'#7c5cff'],['Hasil DNA',c.prec,'#2f7be6'],['Pengamatan',obs,'#2fb344']];
  dialog('Rapor Praktikum', `<p style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin:0 0 10px"><span style="font:800 3rem var(--f-display);color:var(--navy);line-height:1">${total}</span><span class="qbadge" style="font-size:1.4rem">${grade}</span><span>Perkiraan kemurnian: <strong>${c.purity}</strong>/100</span></p>
    ${rows.map(r=>`<div class="rep"><span>${r[0]}</span><div class="bar3"><i style="width:${r[1]}%;background:${r[2]}"></i></div><b>${r[1]}</b></div>`).join('')}
    <ul class="fb">${fb.map(f=>`<li class="${f[0]}">${f[1]}</li>`).join('')}</ul><p class="note">Endapan dari isolasi sederhana masih bercampur RNA, protein, dan pektin, sehingga kemurniannya rendah. Semua angka bersifat ilustratif.</p>`,
    [['Tutup', closeDlg, 'blue'], ['⟲ Ulang praktikum', () => { closeDlg(); L = freshLab(); saveLab(); show(12); }]]);
}

/* ---------------- navigasi ---------------- */
let cur = 1;
const prog = $('#progress'); prog.innerHTML = Array.from({length:TOTAL}, () => '<i></i>').join('');
function updateNext(){ const s = SL[cur-1], nx = $('#next'), locked = s.locked && s.locked();
  nx.classList.toggle('locked', !!locked); nx.innerHTML = locked ? 'Selesaikan dulu 🔒' : cur===11 ? 'Mulai praktikum ▶' : cur===19 ? 'Kuis ▶' : 'Lanjut ▶'; }
function show(n, fromHash){
  n = clamp(n|0, 1, TOTAL); cur = n; const s = SL[n-1], el = $('#stage');
  el.innerHTML = '<section class="scene"></section>'; const sec = el.firstChild; s.render(sec);
  const r = sec.querySelector('.ribbon'); if (r && n>1) r.insertAdjacentHTML('afterbegin', `<span class="n">${n}.</span>`);
  $('#foot').hidden = !!s.nonav; $('#next').hidden = !!s.nonext;
  $('#sceneNo').innerHTML = `${n} / ${TOTAL}<span class="t"> · ${s.title}</span>`;
  [...prog.children].forEach((d,i) => d.className = i+1<n ? 'on' : i+1===n ? 'now' : '');
  if (!fromHash){ try{ history.replaceState(null,'','#s'+n); }catch(e){} }
  store.set('last', n); window.scrollTo({top:0}); updateNext();
}
$('#prev').onclick = () => show(cur-1);
$('#next').onclick = () => { const s = SL[cur-1]; if (s.locked && s.locked()){ toast(s.lockMsg, 'bad'); return; } show(cur+1); };
$('#btnHome').onclick = () => show(1);
addEventListener('hashchange', () => { const m = location.hash.match(/^#s(\d+)$/); if (m && +m[1]!==cur) show(+m[1], true); });
document.addEventListener('keydown', e => { if (!$('#dlg').hidden || e.target.matches('input,textarea,select')) return; if (e.key==='ArrowRight' && !$('#foot').hidden) $('#next').click(); if (e.key==='ArrowLeft' && !$('#foot').hidden) $('#prev').click(); });
$('#btnInfo').onclick = () => {
  const standalone = matchMedia('(display-mode: standalone)').matches || navigator.standalone;
  dialog('Tentang & Pengaturan', `<p><b>Laboratorium Virtual Isolasi DNA Tumbuhan</b>: praktikum isolasi DNA dari buah tomat (<i>Solanum lycopersicum</i>) untuk SMA.</p>
    <p>Dikembangkan oleh: <b>[Nama pengembang]</b> · [Program studi / sekolah] · 2026</p>
    <div class="setrow"><span>Suara efek</span><button class="chip" id="tS" aria-pressed="${soundOn}">${soundOn?'Aktif':'Mati'}</button></div>
    <div class="setrow"><span>Penanda langkah (mode terpandu)</span><button class="chip" id="tG" aria-pressed="${guided()}">${guided()?'Aktif':'Mati'}</button></div>
    <div class="setrow"><span>Hapus semua kemajuan</span><button class="chip" id="tR">Hapus</button></div>
    <div class="install" style="margin-top:12px">${standalone?'✓ Kamu sedang memakai versi aplikasi.':'<b>Pasang sebagai aplikasi (iPad/iPhone):</b> buka di Safari → ketuk tombol Bagikan → <b>Tambah ke Layar Utama</b>. Di Android/Chrome: menu ⋮ → <b>Instal aplikasi</b>. Fitur ini berfungsi bila web dibuka dari alamat hostingnya sendiri.'}</div>
    <p class="note" style="margin-top:8px">Takaran mengikuti rancangan storyboard dan perlu diuji lewat praktikum pendahuluan. Angka hasil di lab virtual bersifat ilustratif.</p>`, [['Tutup', closeDlg]]);
  $('#tS').onclick = e => { soundOn = !soundOn; store.set('sound', soundOn); e.target.setAttribute('aria-pressed', soundOn); e.target.textContent = soundOn?'Aktif':'Mati'; };
  $('#tG').onclick = e => { const g = !guided(); store.set('guided', g); e.target.setAttribute('aria-pressed', g); e.target.textContent = g?'Aktif':'Mati'; show(cur); };
  $('#tR').onclick = () => { try{ Object.keys(localStorage).filter(k=>k.startsWith('dnatomat-')).forEach(k=>localStorage.removeItem(k)); }catch(e){} L = freshLab(); K3 = new Set(); goalN = 0; flowN = 0; qi = 0; qres = []; closeDlg(); show(1); toast('Semua kemajuan dihapus.'); };
};

/* ---------------- PWA ---------------- */
if ('serviceWorker' in navigator && location.protocol.startsWith('http')){ try{ navigator.serviceWorker.register('sw.js').catch(()=>{}); }catch(e){} }

document.body.classList.toggle('noanim', reduce);
const m = location.hash.match(/^#s(\d+)$/);
show(m ? +m[1] : 1, true);
})();
